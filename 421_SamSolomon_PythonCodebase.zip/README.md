# Convexity Sensitivity AI Agent (Project 1B)

Duration, convexity and key-rate sensitivity of a synthetic 300-bond, six-currency portfolio (INR 3,200 crore)
with Monte Carlo VaR/ES, machine-learning pricers, Nelson-Siegel/Svensson curves and back-testing.

## Run
```
pip install -r requirements.txt
cd src
python -m unittest -v test_core      # 14 tests
mkdir -p ../out/fig && python make_ml_pickle.py   # trains the ML models
python run_core.py                   # all results -> ../out/results.pkl   (expects ../out/ml.pkl, see note)
python extra_calcs.py && python build_excel.py && python make_figs.py
```
Note: `run_core.py` loads `../out/ml.pkl`, produced by fitting `ml_models.train_and_evaluate` for the
FEATURES_FULL and FEATURES_RAW sets (see Section A2.4 of the report). Create `out/` and `out/fig/` first.

## Provenance
The portfolio, FX rates, curves and back-test history are SYNTHETIC and seeded. XGBoost*, NeuralNet* in the
results are scikit-learn analogues; `ml_xgb_keras.py` and the R scripts were not executed in the build sandbox.
