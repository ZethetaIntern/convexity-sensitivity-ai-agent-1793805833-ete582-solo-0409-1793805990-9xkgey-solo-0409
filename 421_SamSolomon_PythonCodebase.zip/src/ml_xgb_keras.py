"""ml_xgb_keras.py - production variant using XGBoost, TensorFlow/Keras and the shap library.
NOT EXECUTED in the offline build sandbox (packages unavailable); the scikit-learn analogues in
ml_models.py produced the reported numbers. Run: pip install xgboost tensorflow shap
"""
import numpy as np, pandas as pd, shap, tensorflow as tf
from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from ml_models import make_dataset, make_stress_set, FEATURES_FULL

df, stress = make_dataset(), make_stress_set()
X_tr, X_te, y_tr, y_te = train_test_split(df[FEATURES_FULL], df["price"], test_size=0.2, random_state=42)

rf = RandomForestRegressor(n_estimators=100, min_samples_leaf=2, n_jobs=-1, random_state=42).fit(X_tr, y_tr)
xgb = XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                   early_stopping_rounds=10, random_state=42)
xgb.fit(X_tr, y_tr, eval_set=[(X_te, y_te)], verbose=False)

sc = StandardScaler().fit(X_tr)
nn = tf.keras.Sequential([tf.keras.layers.Input((len(FEATURES_FULL),)),
                          tf.keras.layers.Dense(128, activation="relu"), tf.keras.layers.Dropout(0.2),
                          tf.keras.layers.Dense(64, activation="relu"), tf.keras.layers.Dense(32, activation="relu"),
                          tf.keras.layers.Dense(1)])
nn.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse", metrics=["mae"])
nn.fit(sc.transform(X_tr), y_tr, validation_split=0.1, epochs=200, batch_size=128, verbose=0,
       callbacks=[tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True)])

def score(pred, truth):
    return dict(RMSE=mean_squared_error(truth, pred) ** 0.5, MAE=mean_absolute_error(truth, pred), R2=r2_score(truth, pred))

print("RF ", score(rf.predict(X_te), df.loc[X_te.index, "price_true"]))
print("XGB", score(xgb.predict(X_te), df.loc[X_te.index, "price_true"]))
print("NN ", score(nn.predict(sc.transform(X_te), verbose=0).ravel(), df.loc[X_te.index, "price_true"]))

# --- SHAP ---------------------------------------------------------------------------------
expl = shap.TreeExplainer(xgb)                          # fast, exact for trees
sv = expl.shap_values(X_te.iloc[:500])
shap.summary_plot(sv, X_te.iloc[:500], show=False)
shap.dependence_plot("yield_rate", sv, X_te.iloc[:500], show=False)
shap.dependence_plot("maturity", sv, X_te.iloc[:500], show=False)
deep = shap.DeepExplainer(nn, sc.transform(X_tr.sample(100, random_state=0)))   # neural network
sv_nn = deep.shap_values(sc.transform(X_te.iloc[:200]))
