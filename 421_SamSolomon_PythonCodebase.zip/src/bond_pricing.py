"""bond_pricing.py - core fixed-income mathematics for the Convexity Sensitivity AI Agent.

Conventions
-----------
* Yields are decimals (0.0735 = 7.35%), compounded `freq` times per year.
* Prices are per 100 face. Cash-flow times are in years and may be fractional;
  a short first period pays a full coupon (dirty-price style, no accrual split).
* Convexity is d2P/dy2 / P (units: years^2), so dP/P ~ -D*dy + 0.5*C*dy^2.
"""
from __future__ import annotations

import numpy as np


def cash_flows(face: float, coupon_rate: float, years: float, freq: int = 2):
    """Return (times_in_years, cash_flows) for a plain fixed-coupon bond."""
    if years <= 0:
        raise ValueError("years must be positive")
    step = 1.0 / freq
    n = int(np.ceil(years * freq - 1e-9))
    times = years - step * np.arange(n - 1, -1, -1)      # ascending, last == years
    cf = np.full(n, face * coupon_rate / freq)
    cf[-1] += face
    return times, cf


def bond_price(face, coupon_rate, ytm, years, freq=2):
    t, cf = cash_flows(face, coupon_rate, years, freq)
    return float(np.sum(cf / (1.0 + ytm / freq) ** (freq * t)))


def macaulay_duration(face, coupon_rate, ytm, years, freq=2):
    t, cf = cash_flows(face, coupon_rate, years, freq)
    pv = cf / (1.0 + ytm / freq) ** (freq * t)
    return float(np.sum(t * pv) / np.sum(pv))


def modified_duration(face, coupon_rate, ytm, years, freq=2):
    return macaulay_duration(face, coupon_rate, ytm, years, freq) / (1.0 + ytm / freq)


def convexity(face, coupon_rate, ytm, years, freq=2):
    t, cf = cash_flows(face, coupon_rate, years, freq)
    k = freq * t                                          # periods (may be fractional)
    pv = cf / (1.0 + ytm / freq) ** k
    return float(np.sum(k * (k + 1) * pv) / (np.sum(pv) * freq ** 2 * (1.0 + ytm / freq) ** 2))


def dv01(face, coupon_rate, ytm, years, freq=2):
    """Analytic DV01 per `face` of notional: ModDur x Price / 10,000."""
    return modified_duration(face, coupon_rate, ytm, years, freq) * bond_price(
        face, coupon_rate, ytm, years, freq) / 10_000.0


def dv01_numeric(face, coupon_rate, ytm, years, freq=2, bump=1e-4):
    p_dn = bond_price(face, coupon_rate, ytm - bump / 2, years, freq)
    p_up = bond_price(face, coupon_rate, ytm + bump / 2, years, freq)
    return p_dn - p_up


def effective_duration_convexity(price_fn, y0, dy=1e-4):
    """Finite-difference effective duration/convexity for any pricing function price_fn(y)."""
    p0, p_dn, p_up = price_fn(y0), price_fn(y0 - dy), price_fn(y0 + dy)
    eff_dur = (p_dn - p_up) / (2.0 * p0 * dy)
    eff_conv = (p_dn + p_up - 2.0 * p0) / (p0 * dy ** 2)
    return float(eff_dur), float(eff_conv)


def price_change_estimate(price, mod_dur, conv, dy):
    """Second-order price estimate; returns (duration_effect, convexity_effect, new_price)."""
    d_eff = -mod_dur * dy * price
    c_eff = 0.5 * conv * dy ** 2 * price
    return d_eff, c_eff, price + d_eff + c_eff


# ---- perpetuals (closed forms; annual compounding) ---------------------------------
def perpetual_metrics(y):
    """Annual-pay perpetual at yield y: price=c/y; ModDur=1/y; MacDur=(1+y)/y; Conv=2/y^2."""
    return {"mac_dur": (1 + y) / y, "mod_dur": 1.0 / y, "convexity": 2.0 / y ** 2}


# ---- callable bond via bond-minus-option (smooth, educational) --------------------------
def callable_price_bachelier(face, coupon_rate, ytm, years, call_years, strike=100.0,
                             freq=2, yield_vol=0.0100):
    """Callable price = straight price - European call on the forward bond price.

    The call (exercisable at `call_years` at `strike`) is valued with a normal
    (Bachelier) model on the forward bond price; price vol = ModDur(remaining) x
    forward price x yield_vol. Smooth in yield, so finite-difference *effective*
    duration/convexity are stable. Approximation: single call date, flat curve.
    """
    from math import exp, sqrt
    from scipy.stats import norm
    straight = bond_price(face, coupon_rate, ytm, years, freq)
    rem = years - call_years
    p_call_date = bond_price(face, coupon_rate, ytm, rem, freq)       # value of remainder at call date
    md_rem = modified_duration(face, coupon_rate, ytm, rem, freq)
    # forward price of the remaining bond (strip coupons paid before the call date)
    t, cf = cash_flows(face, coupon_rate, years, freq)
    pv_pre = float(np.sum(cf[t <= call_years + 1e-9] / (1 + ytm / freq) ** (freq * t[t <= call_years + 1e-9])))
    df = (1 + ytm / freq) ** (-freq * call_years)
    fwd = (straight - pv_pre) / df
    sigma = md_rem * fwd * yield_vol * sqrt(call_years)
    d = (fwd - strike) / sigma
    call_val = (fwd - strike) * norm.cdf(d) + sigma * norm.pdf(d)
    return float(straight - df * call_val)


if __name__ == "__main__":
    p = bond_price(100, 0.0726, 0.0735, 9)
    print(round(p, 4), round(macaulay_duration(100, 0.0726, 0.0735, 9), 4),
          round(modified_duration(100, 0.0726, 0.0735, 9), 4),
          round(convexity(100, 0.0726, 0.0735, 9), 4),
          round(dv01(100, 0.0726, 0.0735, 9), 5))
