"""var_backtest.py - VaR back-testing: breach counts, Kupiec POF test, Basel traffic light."""
from __future__ import annotations
import numpy as np
from scipy.stats import chi2


def breaches(pnl, var_series):
    """A breach is a day whose loss exceeds VaR (VaR is a positive loss number)."""
    return int(np.sum(np.asarray(pnl) < -np.asarray(var_series)))


def kupiec_pof(n_breaches, n_obs, conf=0.99):
    """Kupiec (1995) proportion-of-failures likelihood-ratio test. H0: breach rate = 1 - conf."""
    p, x, n = 1.0 - conf, n_breaches, n_obs
    if x == 0:
        lr = -2.0 * n * np.log(1 - p)
    elif x == n:
        lr = -2.0 * n * np.log(p)
    else:
        pi = x / n
        lr = -2.0 * ((n - x) * np.log(1 - p) + x * np.log(p) - (n - x) * np.log(1 - pi) - x * np.log(pi))
    return float(lr), float(1.0 - chi2.cdf(lr, 1))


def basel_zone(n_breaches_250d):
    """Basel traffic light for 99% VaR over 250 trading days."""
    return "Green" if n_breaches_250d <= 4 else ("Yellow" if n_breaches_250d <= 9 else "Red")


def rolling_var_backtest(pnl, window=250, conf=0.99, method="historical"):
    pnl = np.asarray(pnl)
    var, act = [], []
    for t in range(window, len(pnl)):
        h = pnl[t - window:t]
        if method == "historical":
            var.append(-np.percentile(h, (1 - conf) * 100))
        else:                                              # delta-normal
            from scipy.stats import norm
            var.append(norm.ppf(conf) * h.std(ddof=1) - h.mean())
        act.append(pnl[t])
    return np.array(act), np.array(var)
