"""ml_models.py - Random Forest, gradient-boosted trees and neural-network bond pricers.

Environment note: xgboost and tensorflow are not installable in the offline build sandbox,
so the executed results use drop-in scikit-learn analogues (GradientBoostingRegressor with the
same depth / rounds / learning-rate / subsample as the XGBoost spec, and MLPRegressor with the
same 128-64-32 architecture). The XGBoost / Keras versions are provided as build_xgboost() and
build_keras() and are used automatically when the libraries are importable.
"""
from __future__ import annotations

import time
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from bond_pricing import bond_price, macaulay_duration, convexity

FEATURES_FULL = ["coupon_rate", "maturity", "yield_rate", "duration", "convexity"]
FEATURES_RAW = ["coupon_rate", "maturity", "yield_rate"]


def make_dataset(n=30_000, seed=7, y_range=(0.045, 0.095), noise=0.05, cpn_range=(0.04, 0.10)):
    """Synthetic universe of semi-annual fixed-coupon bonds priced by first principles."""
    rng = np.random.default_rng(seed)
    cpn = np.round(rng.uniform(*cpn_range, n), 4)
    mat = rng.integers(2, 61, n) / 2.0                                   # 1.0 .. 30.0 in half-years
    y = rng.uniform(*y_range, n)
    price = np.array([bond_price(100, c, yy, m) for c, yy, m in zip(cpn, y, mat)])
    dur = np.array([macaulay_duration(100, c, yy, m) for c, yy, m in zip(cpn, y, mat)])
    cvx = np.array([convexity(100, c, yy, m) for c, yy, m in zip(cpn, y, mat)])
    df = pd.DataFrame(dict(coupon_rate=cpn, maturity=mat, yield_rate=y, duration=dur, convexity=cvx,
                           price_true=price))
    df["price"] = price + rng.normal(0, noise, n)                        # quote / bid-ask noise
    return df


def build_models(random_state=42):
    models = {"RandomForest": RandomForestRegressor(n_estimators=100, min_samples_leaf=2, n_jobs=-1,
                                                    random_state=random_state)}
    try:
        from xgboost import XGBRegressor
        models["XGBoost"] = XGBRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                                         subsample=0.8, colsample_bytree=0.8, random_state=random_state)
    except ImportError:
        models["XGBoost*"] = GradientBoostingRegressor(n_estimators=200, max_depth=4, learning_rate=0.1,
                                                       subsample=0.8, random_state=random_state)
    models["NeuralNet*"] = make_pipeline(
        StandardScaler(),
        MLPRegressor(hidden_layer_sizes=(128, 64, 32), activation="relu", solver="adam",
                     learning_rate_init=1e-3, early_stopping=True, n_iter_no_change=10,
                     max_iter=400, random_state=random_state))
    return models


def build_keras(n_features=5):                      # used when tensorflow is available
    import tensorflow as tf
    m = tf.keras.Sequential([tf.keras.layers.Input((n_features,)),
                             tf.keras.layers.Dense(128, activation="relu"), tf.keras.layers.Dropout(0.2),
                             tf.keras.layers.Dense(64, activation="relu"),
                             tf.keras.layers.Dense(32, activation="relu"), tf.keras.layers.Dense(1)])
    m.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse")
    return m


def metrics(y_true, y_pred):
    return dict(RMSE=float(np.sqrt(mean_squared_error(y_true, y_pred))),
                MAE=float(mean_absolute_error(y_true, y_pred)), R2=float(r2_score(y_true, y_pred)))


def train_and_evaluate(features, df=None, stress=None, seed=42):
    df = make_dataset() if df is None else df
    X_tr, X_te, y_tr, y_te = train_test_split(df[features], df["price"], test_size=0.2, random_state=seed)
    fitted, rows = {}, []
    for name, model in build_models(seed).items():
        t0 = time.time(); model.fit(X_tr, y_tr); fit_s = time.time() - t0
        row = {"Model": name, "Features": len(features), "FitSeconds": fit_s}
        row.update({f"Test_{k}": v for k, v in metrics(df.loc[X_te.index, "price_true"], model.predict(X_te)).items()})
        if stress is not None:
            row.update({f"Stress_{k}": v for k, v in metrics(stress["price_true"], model.predict(stress[features])).items()})
        rows.append(row); fitted[name] = model
    return fitted, pd.DataFrame(rows), (X_tr, X_te, y_tr, y_te)


def make_stress_set(n=3_000, seed=99):
    """Out-of-range test: yields 9.5-12.5 % lie entirely outside the 4.5-9.5 % training domain."""
    return make_dataset(n=n, seed=seed, y_range=(0.095, 0.125), noise=0.0)
