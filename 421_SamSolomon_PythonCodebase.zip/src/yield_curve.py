"""yield_curve.py - Nelson-Siegel / Svensson fitting, zero-curve bootstrapping, forwards, PCA."""
from __future__ import annotations
import numpy as np
from scipy.optimize import least_squares


def ns_curve(tau, b0, b1, b2, lam):
    x = np.asarray(tau, dtype=float) / lam
    f1 = (1 - np.exp(-x)) / x
    return b0 + b1 * f1 + b2 * (f1 - np.exp(-x))


def svensson_curve(tau, b0, b1, b2, b3, lam1, lam2):
    x2 = np.asarray(tau, dtype=float) / lam2
    f3 = (1 - np.exp(-x2)) / x2 - np.exp(-x2)
    return ns_curve(tau, b0, b1, b2, lam1) + b3 * f3


def _fit(fun, tau, y, starts, lower, upper):
    best = None
    for p0 in starts:
        r = least_squares(lambda p: fun(tau, *p) - y, p0, bounds=(lower, upper), xtol=1e-12, ftol=1e-12)
        if best is None or r.cost < best.cost:
            best = r
    return best


def fit_nelson_siegel(tau, y):
    tau, y = np.asarray(tau, float), np.asarray(y, float)
    starts = [[y[-1], y[0] - y[-1], 0.0, lam] for lam in (0.5, 1.5, 3.0, 6.0)]
    r = _fit(ns_curve, tau, y, starts, [-0.05, -0.2, -0.2, 0.05], [0.3, 0.2, 0.2, 30.0])
    return r.x, ns_curve(tau, *r.x)


def fit_svensson(tau, y):
    tau, y = np.asarray(tau, float), np.asarray(y, float)
    starts = [[y[-1], y[0] - y[-1], 0.0, 0.0, l1, l2] for l1, l2 in ((1, 5), (2, 8), (0.7, 3), (3, 12))]
    r = _fit(svensson_curve, tau, y, starts, [-0.05, -0.2, -0.2, -0.2, 0.05, 0.05], [0.3, 0.2, 0.2, 0.2, 30, 30])
    return r.x, svensson_curve(tau, *r.x)


def fit_stats(y, yhat):
    sse = float(((y - yhat) ** 2).sum()); sst = float(((y - y.mean()) ** 2).sum())
    return dict(R2=1 - sse / sst, RMSE_bp=float(np.sqrt(sse / len(y)) * 1e4),
                MaxErr_bp=float(np.abs(y - yhat).max() * 1e4))


def bootstrap_zero_curve(maturities, coupons, prices, freq=2, face=100.0):
    """Sequential bootstrap from par-style coupon bonds with consecutive maturities
    (0.5, 1.0, ... in half-year steps). Returns semi-annual-compounded zero rates."""
    z = []
    for n, (c, P) in enumerate(zip(coupons, prices), start=1):
        cpn = face * c / freq
        pv_prev = sum(cpn / (1 + z[i] / freq) ** (i + 1) for i in range(n - 1))
        z.append(freq * (((face + cpn) / (P - pv_prev)) ** (1.0 / n) - 1.0))
    return np.array(maturities, float), np.array(z)


def discount_factor(z, t, freq=2):
    return (1 + np.asarray(z) / freq) ** (-freq * np.asarray(t))


def forward_rate(z1, t1, z2, t2, freq=2):
    """Implied forward rate between t1 and t2 (same compounding as z)."""
    g = (discount_factor(z1, t1, freq) / discount_factor(z2, t2, freq)) ** (1.0 / (freq * (t2 - t1))) - 1
    return freq * g


def pca_factors(dy_matrix, n=3):
    X = dy_matrix - dy_matrix.mean(axis=0)
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    var = S ** 2 / (S ** 2).sum()
    return Vt[:n], var[:n], U[:, :n] * S[:n]
