import pickle, numpy as np, pandas as pd
from portfolio_analytics import *
from bond_pricing import *
R = pickle.load(open("../out/results.pkl", "rb"))
df = R["pf"]["df"]; book = BookRepricer(df); S = R["pf"]["S"]; kmat = R["pf"]["kmat"]
E = {}
# --- RBI Surprise (B3.2): short end +60, long end +30 (>=10Y), linear in between, all curves
def shock_profile(short_bp, long_bp, t_short=2.0, t_long=10.0, inr_only=False):
    sh = np.interp(book.T, [t_short, t_long], [short_bp, long_bp]) / 1e4
    return sh * (book.ccy_flat == "INR") if inr_only else sh
for lab, inr in (("all", False), ("inr", True)):
    sh = shock_profile(60, 30, inr_only=inr); full = book.pnl(sh)
    key_sh = np.interp(KEY_TENORS, [2, 10], [60, 30]) / 1e4
    if inr:
        mv_k = np.array([(book.base_mv[i] * kmat[i]) if df.Currency.iloc[i] == "INR" else 0 * kmat[i] for i in range(len(df))]).sum(axis=0)
    else:
        mv_k = (book.base_mv[:, None] * kmat).sum(axis=0)
    krd = -(mv_k * key_sh).sum()
    avg = 45e-4
    E[f"rbi_{lab}"] = dict(full=full, krd=krd, naive=-S["mod_dur"] * avg * S["total_mv_inr"] if not inr else None)
# worst hit by segment (INR repricing contributions)
sh = shock_profile(60, 30, inr_only=False); base = book.mv(book.price(np.zeros_like(book.T))); new = book.mv(book.price(sh))
d = pd.DataFrame({"Segment": df.Segment, "Currency": df.Currency, "pnl": new - base}).groupby("Segment").pnl.sum().sort_values()
E["rbi_by_seg"] = d
# DV01 hedge: pay-fixed 10Y swaps notional to cut DV01 by 50%
E["hedge_notional_cr"] = S["dv01_inr"] * 0.5 / (modified_duration(100, float(zero_rate("INR", 10)), float(zero_rate("INR", 10)), 10) / 1e4) / 1e7
# --- Operation Twist: 10Y+ -12.5bp, 1-3Y +6.5bp, INR only
pt = np.array([6.5, 6.5, 6.5, 6.5, 6.5, 4.0, 0.0, -12.5, -12.5, -12.5])  # 3M..3Y +6.5, 5Y/7Y fade, 10Y+ -12.5 (illustrative interpolation)
shk = np.interp(book.T, KEY_TENORS, pt) / 1e4 * (book.ccy_flat == "INR")
E["twist"] = dict(full=book.pnl(shk), pt=pt)
# --- RBI hike replay for C1.5 (INR assets only; pass-through 100% <=1Y fading to 19% at 10Y)
hikes = [("4-May-22 (off-cycle)", 40), ("8-Jun-22", 50), ("5-Aug-22", 50), ("30-Sep-22", 50), ("7-Dec-22", 35), ("8-Feb-23", 25)]
def passthrough(t): return np.interp(t, [1.0, 10.0], [1.0, 0.19])
rows, cum = [], 0
prev_mv = book.base_mv.sum()
for lab, bp in hikes:
    cum += bp; shc = passthrough(book.T) * cum / 1e4 * (book.ccy_flat == "INR")
    mv_now = book.mv(book.price(shc)).sum(); pnl = mv_now - book.base_mv.sum()
    inr = (df.Currency == "INR").to_numpy(); bump = 1e-4 * (book.ccy_flat == "INR")
    up = book.mv(book.price(shc + bump))[inr].sum(); dn = book.mv(book.price(shc - bump))[inr].sum(); mid = book.mv(book.price(shc))[inr].sum()
    eff = (dn - up) / (2e-4 * mid)
    rows.append(dict(Event=lab, Hike=bp, CumRepo=cum, Y10=passthrough(10.0) * cum, Y2=passthrough(2.0) * cum, CumPnL=pnl, StepPnL=pnl - (rows[-1]["CumPnL"] if rows else 0), EffDur=eff))
E["replay"] = pd.DataFrame(rows)
# duration-only estimate for the total (using initial duration & average 10Y-like pass-through)
E["replay_dur_only"] = -S["mod_dur"] * (0.0048) * S["total_mv_inr"]
inv = np.interp(book.T, [2, 10, 30], [100, -25, -25]) / 1e4 * (book.ccy_flat == "INR")
E["inv"] = dict(full=book.pnl(inv), par100_inr=book.pnl(np.full_like(book.T, 0.01) * (book.ccy_flat == "INR")))
pickle.dump(E, open("../out/extra.pkl", "wb"))
print({k: (v if not isinstance(v, (pd.DataFrame, pd.Series)) else None) for k, v in E.items()})
print(E["replay"].round(3).to_string()); print(E["rbi_by_seg"] / 1e7)
