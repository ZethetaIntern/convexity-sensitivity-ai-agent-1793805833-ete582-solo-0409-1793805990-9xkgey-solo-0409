"""portfolio_analytics.py - synthetic 300-bond multi-currency portfolio, bond-level and
portfolio-level duration / convexity / DV01, Key Rate Durations and contribution analysis.

All market inputs below are ILLUSTRATIVE snapshots (see report Section D.3). Replace
CURVES / FX with CCIL-FIMMDA / central-bank downloads for live use.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import brentq

from bond_pricing import cash_flows, bond_price, macaulay_duration, modified_duration, convexity

TENORS = np.array([0.25, 0.5, 1, 2, 3, 5, 7, 10, 15, 20, 30], dtype=float)   # 11 standard INR points
KEY_TENORS = np.array([0.25, 0.5, 1, 2, 3, 5, 7, 10, 20, 30], dtype=float)  # 10 KRD buckets
KEY_LABELS = ["3M", "6M", "1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "20Y", "30Y"]

CURVES = {  # zero-rate knots in % (illustrative)
    "INR": [6.62, 6.64, 6.69, 6.78, 6.88, 7.05, 7.2, 7.37, 7.55, 7.66, 7.77],
    "USD": [4.35, 4.30, 4.20, 4.05, 4.00, 4.05, 4.15, 4.30, 4.65, 4.85, 4.85],
    "GBP": [4.20, 4.15, 4.05, 3.95, 3.95, 4.00, 4.15, 4.35, 4.75, 4.95, 4.90],
    "EUR": [2.05, 2.05, 2.10, 2.20, 2.30, 2.50, 2.65, 2.80, 3.10, 3.20, 3.15],
    "JPY": [0.50, 0.55, 0.65, 0.80, 0.95, 1.15, 1.35, 1.60, 2.05, 2.35, 2.65],
    "AUD": [3.80, 3.75, 3.70, 3.75, 3.85, 4.00, 4.15, 4.35, 4.65, 4.80, 4.80],
}
FX_INR = {"INR": 1.0, "USD": 88.0, "GBP": 115.0, "EUR": 100.0, "JPY": 0.58, "AUD": 58.0}  # illustrative
CCY_VOL_SCALE = {"INR": 1.0, "USD": 1.15, "GBP": 1.10, "EUR": 0.80, "JPY": 0.45, "AUD": 1.00}
TARGET_MV_INR = 3_200e7          # INR 3,200 crore
SEGMENT_SHARE = {"GSEC": 0.38, "SDL": 0.10, "CORP_AAA": 0.13, "CORP_AA": 0.08, "CORP_A": 0.04,
                 "UST": 0.10, "GILT": 0.05, "BUND": 0.06, "JGB": 0.03, "ACGB": 0.03}


def zero_rate(ccy: str, t):
    return np.interp(t, TENORS, np.array(CURVES[ccy]) / 100.0)


# ------------------------------------------------------------------------------------
# Yield-curve shock shapes (loadings per 1 bp of the named factor)
# ------------------------------------------------------------------------------------
def level_shape(t):
    return np.ones_like(np.asarray(t, dtype=float))


def _g(t):
    return 1.0 - np.exp(-np.asarray(t, dtype=float) / 4.0)


def twist_shape(t):
    """Slope factor normalised so that shock(10Y) - shock(2Y) = 1 (bounded at the long end)."""
    return (_g(t) - _g(5.0)) / (_g(10.0) - _g(2.0))


def _bump(t):
    return np.exp(-((np.asarray(t, dtype=float) - 5.0) / 3.0) ** 2)


def butterfly_shape(t):
    """Curvature factor normalised so that 2*s(5Y) - s(2Y) - s(10Y) = 1."""
    k = 2 * _bump(5.0) - _bump(2.0) - _bump(10.0)
    return _bump(t) / k


def hat(t, k_index: int):
    """Triangular key-rate bump: 1 at KEY_TENORS[k], linearly 0 at neighbours, flat beyond ends."""
    e = np.zeros(len(KEY_TENORS)); e[k_index] = 1.0
    return np.interp(t, KEY_TENORS, e)


# ------------------------------------------------------------------------------------
# Portfolio construction (synthetic, seeded)
# ------------------------------------------------------------------------------------
SEGMENTS = [  # name, ccy, sector, rating, count, spread_bps, freq
    ("GSEC", "INR", "Government", "SOV", 75, 0, 2),
    ("SDL", "INR", "Government", "SOV", 35, 35, 2),
    ("CORP_AAA", "INR", "Corporate", "AAA", 45, 70, 1),
    ("CORP_AA", "INR", "NBFC", "AA", 35, 130, 1),
    ("CORP_A", "INR", "NBFC", "A", 20, 230, 1),
    ("UST", "USD", "Government", "SOV", 25, 0, 2),
    ("GILT", "GBP", "Government", "SOV", 15, 0, 2),
    ("BUND", "EUR", "Government", "SOV", 20, 0, 1),
    ("JGB", "JPY", "Government", "SOV", 15, 0, 2),
    ("ACGB", "AUD", "Government", "SOV", 15, 0, 2),
]


def curve_price(face, cpn, years, freq, ccy, spread, bump_fn=None):
    t, cf = cash_flows(face, cpn, years, freq)
    z = zero_rate(ccy, t) + spread + (0.0 if bump_fn is None else bump_fn(t))
    return float(np.sum(cf / (1.0 + z / freq) ** (freq * t)))


def build_portfolio(seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows, bid = [], 1
    for seg, ccy, sector, rating, n, spr_bp, freq in SEGMENTS:
        for _ in range(n):
            years = float(np.round(rng.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30],
                                              p=_maturity_probs(seg)), 0))
            spread = (spr_bp + rng.normal(0, 8)) / 1e4 if spr_bp else 0.0
            par = zero_rate(ccy, years) + spread
            cpn = float(np.round(par * 100 / 0.05) * 0.05 / 100)                 # coupon ~ par, 5bp grid
            price = curve_price(100, cpn, years, freq, ccy, spread)
            ytm = brentq(lambda y: bond_price(100, cpn, y, years, freq) - price, -0.05, 0.60)
            rows.append(dict(BondID=f"B{bid:03d}", Segment=seg, Currency=ccy, Sector=sector,
                             CreditRating=rating, CouponRate=cpn, CouponFrequency=freq,
                             YearsToMaturity=years, Spread=spread, YieldToMaturity=ytm,
                             Price=price, FaceWeight=float(rng.lognormal(0, 0.6))))
            bid += 1
    df = pd.DataFrame(rows)
    fx = df["Currency"].map(FX_INR)
    seg_total = df.groupby("Segment")["FaceWeight"].transform("sum")
    df["MV_INR"] = df["Segment"].map(SEGMENT_SHARE) * TARGET_MV_INR * df["FaceWeight"] / seg_total
    df["FaceLocal"] = df["MV_INR"] / (df["Price"] / 100 * fx)       # face amount in local currency
    df["PortfolioWeight"] = df["MV_INR"] / df["MV_INR"].sum()
    df["MacaulayDuration"] = [macaulay_duration(100, r.CouponRate, r.YieldToMaturity, r.YearsToMaturity, r.CouponFrequency) for r in df.itertuples()]
    df["ModifiedDuration"] = [modified_duration(100, r.CouponRate, r.YieldToMaturity, r.YearsToMaturity, r.CouponFrequency) for r in df.itertuples()]
    df["Convexity"] = [convexity(100, r.CouponRate, r.YieldToMaturity, r.YearsToMaturity, r.CouponFrequency) for r in df.itertuples()]
    df["DV01_Per100Face"] = df["ModifiedDuration"] * df["Price"] / 10_000
    df["DV01_INR"] = df["ModifiedDuration"] * df["MV_INR"] / 10_000
    df["KeyRateBucket"] = [KEY_LABELS[int(np.argmin(np.abs(KEY_TENORS - m)))] for m in df["YearsToMaturity"]]
    return df


def _maturity_probs(seg):
    base = np.array([6, 7, 8, 8, 9, 9, 8, 9, 6, 6, 5, 5, 5, 4, 5], dtype=float)
    if seg in ("GSEC", "UST", "GILT", "BUND", "JGB", "ACGB"):
        base = base * np.array([1, 1, 1, 1, 1, 1, 1.4, 1.8, 1.2, 1.2, 1.6, 1.6, 1.8, 1.4, 1.8])
    if seg.startswith("CORP"):
        base = base * np.array([2, 2.5, 3, 2.5, 2.5, 1.5, 0.8, 0.8, 0.3, 0.2, 0.1, 0.05, 0.02, 0.02, 0.01])
    return base / base.sum()


# ------------------------------------------------------------------------------------
# Flat cash-flow engine for fast full repricing of the entire book
# ------------------------------------------------------------------------------------
class BookRepricer:
    """Stacks every cash flow of every bond so that a whole-book revaluation under any
    zero-curve shock is a handful of vectorised NumPy calls."""

    def __init__(self, df: pd.DataFrame):
        self.df = df.reset_index(drop=True)
        T, CF, Z, F, idx = [], [], [], [], []
        for i, r in enumerate(self.df.itertuples()):
            t, cf = cash_flows(100, r.CouponRate, r.YearsToMaturity, r.CouponFrequency)
            T.append(t); CF.append(cf)
            Z.append(zero_rate(r.Currency, t) + r.Spread)
            F.append(np.full(len(t), r.CouponFrequency)); idx.append(np.full(len(t), i))
        self.T, self.CF, self.Z = map(np.concatenate, (T, CF, Z))
        self.F, self.idx = np.concatenate(F), np.concatenate(idx)
        self.starts = np.r_[0, np.flatnonzero(np.diff(self.idx)) + 1]
        self.ccy = self.df["Currency"].to_numpy()
        self.ccy_flat = self.ccy[self.idx]
        self.scale_flat = np.array([CCY_VOL_SCALE[c] for c in self.ccy_flat])
        self.fx = self.df["Currency"].map(FX_INR).to_numpy()
        self.face = self.df["FaceLocal"].to_numpy()
        self.base_price = self.price(np.zeros_like(self.T))
        self.base_mv = self.mv(self.base_price)

    def price(self, shock_flat):
        """Per-100-face price of each bond given a zero-rate shock (decimal) at every cash flow."""
        pv = self.CF / (1.0 + (self.Z + shock_flat) / self.F) ** (self.F * self.T)
        return np.add.reduceat(pv, self.starts)

    def mv(self, prices):
        return self.face * prices / 100.0 * self.fx

    def pnl(self, shock_flat):
        return float(self.mv(self.price(shock_flat)).sum() - self.base_mv.sum())

    # -- shocks -----------------------------------------------------------------------
    def factor_shock(self, level_bp=0.0, twist_bp=0.0, fly_bp=0.0, scale_by_ccy=True):
        s = (level_bp * level_shape(self.T) + twist_bp * twist_shape(self.T)
             + fly_bp * butterfly_shape(self.T)) / 1e4
        return s * self.scale_flat if scale_by_ccy else s

    def krd_matrix(self, bump=1e-4):
        """(n_bonds x 10) Key Rate Durations by central differences on triangular bumps."""
        out = np.zeros((len(self.df), len(KEY_TENORS)))
        for k in range(len(KEY_TENORS)):
            h = hat(self.T, k) * bump
            out[:, k] = (self.price(-h) - self.price(h)) / (2.0 * self.base_price * bump)
        return out


# ------------------------------------------------------------------------------------
# Aggregations
# ------------------------------------------------------------------------------------
def portfolio_summary(df: pd.DataFrame) -> dict:
    w = df["PortfolioWeight"]
    return dict(
        total_mv_inr=float(df["MV_INR"].sum()),
        mod_dur=float((w * df["ModifiedDuration"]).sum()),
        mac_dur=float((w * df["MacaulayDuration"]).sum()),
        convexity=float((w * df["Convexity"]).sum()),
        dv01_inr=float(df["DV01_INR"].sum()),
        n_bonds=int(len(df)),
    )


def contribution(df: pd.DataFrame, by: str) -> pd.DataFrame:
    g = df.assign(DurContribution=df["PortfolioWeight"] * df["ModifiedDuration"],
                  ConvContribution=df["PortfolioWeight"] * df["Convexity"]).groupby(by)
    out = g.agg(Bonds=("BondID", "count"), Weight=("PortfolioWeight", "sum"),
                DurContribution=("DurContribution", "sum"),
                ConvContribution=("ConvContribution", "sum"), DV01_INR=("DV01_INR", "sum"))
    out["DurShare"] = out["DurContribution"] / out["DurContribution"].sum()
    return out.sort_values("DurContribution", ascending=False)


def portfolio_krd(book: BookRepricer):
    k = book.krd_matrix()
    w = book.df["PortfolioWeight"].to_numpy()
    return k, (w[:, None] * k).sum(axis=0)


def duration_convexity_pnl(summary: dict, dy: float):
    d = -summary["mod_dur"] * dy * summary["total_mv_inr"]
    c = 0.5 * summary["convexity"] * dy ** 2 * summary["total_mv_inr"]
    return d, c, d + c


if __name__ == "__main__":
    df = build_portfolio()
    print(portfolio_summary(df))
