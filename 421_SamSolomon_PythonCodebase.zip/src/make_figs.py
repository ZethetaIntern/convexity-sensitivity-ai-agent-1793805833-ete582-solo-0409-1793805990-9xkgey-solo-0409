import pickle, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from scipy import stats
from bond_pricing import *
from portfolio_analytics import *
from yield_curve import ns_curve, svensson_curve, forward_rate
R = pickle.load(open("../out/results.pkl", "rb")); O = "../out/fig/"
NAVY, TEAL, ORG, RED, GREY = "#1F3864", "#2A9D8F", "#E9873A", "#C0392B", "#7F8C8D"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": .25, "figure.dpi": 100})
def save(n): plt.tight_layout(); plt.savefig(O + n + ".png", dpi=170); plt.close()
cr = 1e7

# F1 price-yield curve with tangent and quadratic
c, y0, n = .0726, .0735, 9; P0 = bond_price(100, c, y0, n); md = modified_duration(100, c, y0, n); cv = convexity(100, c, y0, n)
ys = np.linspace(.02, .13, 200); true = [bond_price(100, c, y, n) for y in ys]
fig, ax = plt.subplots(figsize=(6.4, 3.6)); ax.plot(ys * 100, true, color=NAVY, lw=2, label="Full repricing")
ax.plot(ys * 100, P0 * (1 - md * (ys - y0)), "--", color=ORG, label="Duration only (tangent)")
ax.plot(ys * 100, P0 * (1 - md * (ys - y0) + .5 * cv * (ys - y0) ** 2), ":", color=TEAL, lw=2, label="Duration + convexity")
ax.scatter([y0 * 100], [P0], color=RED, zorder=5); ax.set_xlabel("Yield (%)"); ax.set_ylabel("Price per 100 face"); ax.set_ylim(60, 150); ax.legend(frameon=False)
ax.set_title("7.26% 9-year bond: price-yield relationship"); save("f01_price_yield")
# F2 error vs shock
sh = np.arange(-300, 301, 10); e1 = []; e2 = []
for s in sh:
    dy = s / 1e4; t_ = bond_price(100, c, y0 + dy, n); e1.append(P0 * (1 - md * dy) - t_); e2.append(P0 * (1 - md * dy + .5 * cv * dy ** 2) - t_)
fig, ax = plt.subplots(figsize=(6.4, 3.2)); ax.plot(sh, e1, color=ORG, label="Duration-only error"); ax.plot(sh, e2, color=TEAL, label="Duration+convexity error"); ax.axhline(0, color="k", lw=.6)
ax.set_xlabel("Parallel yield shift (bp)"); ax.set_ylabel("Estimate - true price"); ax.legend(frameon=False); ax.set_title("Approximation error of the price-change formulas"); save("f02_error")
# F3 callable vs straight
yy = np.linspace(.04, .12, 80); cal = [callable_price_bachelier(100, .08, q, 10, 3) for q in yy]; stt = [bond_price(100, .08, q, 10) for q in yy]
cs_ = R["cs"]["callable"]
fig, ax = plt.subplots(1, 2, figsize=(6.6, 3.2)); ax[0].plot(yy * 100, stt, color=NAVY, label="Straight"); ax[0].plot(yy * 100, cal, color=RED, label="Callable (3y, par)"); ax[0].axhline(100, color=GREY, lw=.6, ls=":")
ax[0].set_xlabel("Yield (%)"); ax[0].set_ylabel("Price"); ax[0].legend(frameon=False); ax[0].set_title("Price compression")
ax[1].plot(cs_.y * 100, cs_.eff_conv, "o-", color=RED, label="Callable"); ax[1].plot(cs_.y * 100, cs_.s_conv, "s-", color=NAVY, label="Straight"); ax[1].axhline(0, color="k", lw=.6)
ax[1].set_xlabel("Yield (%)"); ax[1].set_ylabel("Effective convexity"); ax[1].legend(frameon=False); ax[1].set_title("Negative convexity zone"); save("f03_callable")
# F4 KRD bars + heatmap
fig, ax = plt.subplots(1, 2, figsize=(6.8, 3.4), gridspec_kw={"width_ratios": [1, 1.25]}); ax[0].bar(KEY_LABELS, R["pf"]["pk"], color=NAVY); ax[0].set_ylabel("KRD (years)"); ax[0].set_title("Portfolio KRD profile"); ax[0].tick_params(axis="x", rotation=45)
sk = R["pf"]["seg_krd"]; im = ax[1].imshow(sk.values, cmap="YlOrRd", aspect="auto"); ax[1].set_xticks(range(10)); ax[1].set_xticklabels(KEY_LABELS, rotation=45); ax[1].set_yticks(range(len(sk))); ax[1].set_yticklabels(sk.index, fontsize=7)
ax[1].grid(False); ax[1].set_title("KRD contribution: segment x tenor"); plt.colorbar(im, ax=ax[1], fraction=.046); save("f04_krd")
# F5 contributions
fig, ax = plt.subplots(1, 3, figsize=(6.8, 3)); 
for a, k_, t_ in zip(ax, ["by_ccy", "by_rating", "by_seg"], ["Currency", "Rating", "Segment"]):
    d = R["pf"][k_]["DurContribution"]; a.barh(d.index[::-1], d.values[::-1], color=TEAL); a.set_title("Duration by " + t_, fontsize=8); a.tick_params(labelsize=7)
save("f05_contrib")
# F6 MC histogram
p = R["mc"]["pnl_daily"]["full_reval"] / cr; m = R["mc"]
v95, v99, e95 = -np.percentile(p, 5), -np.percentile(p, 1), -p[p <= np.percentile(p, 5)].mean()
fig, ax = plt.subplots(figsize=(6.4, 3.4)); ax.hist(p, bins=70, color=NAVY, alpha=.85); ax.axvline(-v95, color=ORG, lw=2, label=f"VaR95 = INR {v95:.1f} cr"); ax.axvline(-v99, color=RED, lw=2, label=f"VaR99 = INR {v99:.1f} cr"); ax.axvline(-e95, color="k", ls="--", label=f"ES95 = INR {e95:.1f} cr")
ax.set_xlabel("1-day P&L (INR crore)"); ax.set_ylabel("Scenarios"); ax.legend(frameon=False); ax.set_title("10,000-scenario full-revaluation P&L, 3-factor model"); save("f06_mc_hist")
# F7 qq + tail
fig, ax = plt.subplots(1, 2, figsize=(6.8, 3.2)); stats.probplot(p, dist="norm", plot=ax[0]); ax[0].get_lines()[0].set_markersize(2); ax[0].set_title("QQ plot of 1-day P&L")
tl = R["mc_tail"]; lab = ["VaR95", "VaR99", "ES95", "ES99"]; xx = np.arange(4)
ax[1].bar(xx - .2, [tl["Normal"][k_] / cr for k_ in lab], .4, color=NAVY, label="Normal"); ax[1].bar(xx + .2, [tl["Student-t(5)"][k_] / cr for k_ in lab], .4, color=RED, label="Student-t(5)")
ax[1].set_xticks(xx); ax[1].set_xticklabels(lab); ax[1].set_ylabel("INR crore"); ax[1].legend(frameon=False); ax[1].set_title("Tail-risk under fat tails"); save("f07_tail")
# F8 stress
st = R["stress"]; fig, ax = plt.subplots(figsize=(6.6, 3.3)); xx = np.arange(len(st)); ax.bar(xx - .2, st.KRD_first / cr, .4, color=ORG, label="KRD first-order"); ax.bar(xx + .2, st.Full / cr, .4, color=NAVY, label="Full revaluation")
ax.set_xticks(xx); ax.set_xticklabels(st.Scenario, rotation=30, ha="right", fontsize=7); ax.axhline(0, color="k", lw=.6); ax.set_ylabel("P&L (INR crore)"); ax.legend(frameon=False); ax.set_title("Multi-factor stress matrix"); save("f08_stress")
# F9 yield curve
yc = R["yc"]; tt = np.linspace(.25, 30, 200); fig, ax = plt.subplots(1, 2, figsize=(6.8, 3.2))
ax[0].scatter(TENORS, yc["obs"] * 100, color=RED, zorder=4, label="Observed"); ax[0].plot(tt, ns_curve(tt, *yc["ns_p"]) * 100, color=NAVY, label=f"Nelson-Siegel (R2={yc['ns_s']['R2']:.4f})"); ax[0].plot(tt, svensson_curve(tt, *yc["sv_p"]) * 100, "--", color=TEAL, label=f"Svensson (R2={yc['sv_s']['R2']:.4f})")
ax[0].set_xlabel("Tenor (yrs)"); ax[0].set_ylabel("Zero yield (%)"); ax[0].legend(frameon=False, fontsize=7); ax[0].set_title("Parametric fits")
fw = [forward_rate(ns_curve(t, *yc["ns_p"]), t, ns_curve(t + 1, *yc["ns_p"]), t + 1) for t in tt[:-6]]; ax[1].plot(tt[:-6], np.array(fw) * 100, color=ORG, label="1-yr forward"); ax[1].plot(tt, ns_curve(tt, *yc["ns_p"]) * 100, color=NAVY, label="Zero"); ax[1].legend(frameon=False); ax[1].set_xlabel("Tenor (yrs)"); ax[1].set_title("Zero vs forward curve"); save("f09_curve")
# F10 ML
ml = R["ml"]["full"]; fig, ax = plt.subplots(1, 2, figsize=(6.8, 3.1)); xx = np.arange(3); ax[0].bar(xx - .2, ml.Test_RMSE, .4, color=NAVY, label="In-sample range"); ax[0].bar(xx + .2, ml.Stress_RMSE, .4, color=RED, label="Out-of-range (9.5-12.5%)")
ax[0].set_xticks(xx); ax[0].set_xticklabels(ml.Model, fontsize=7); ax[0].set_ylabel("RMSE (price points)"); ax[0].legend(frameon=False, fontsize=7); ax[0].set_title("Pricing RMSE")
tab = R["sens"]["Long30Y"][0]
for col, sty in [("true_dP", ("k", "-")), ("duration_convexity", (TEAL, "--")), ("NeuralNet*", (RED, "-")), ("RandomForest", (ORG, ":"))]: ax[1].plot(tab.shift_bp, tab[col], sty[1], color=sty[0], label=col)
ax[1].set_xlabel("Shift (bp)"); ax[1].set_ylabel("Price change"); ax[1].legend(frameon=False, fontsize=6); ax[1].set_title("30Y bond: ML vs analytical dP"); save("f10_ml")
# F11 error vs shift ML
fig, ax = plt.subplots(figsize=(6.4, 3.1))
for col, color in [("duration_only", ORG), ("duration_convexity", TEAL), ("RandomForest", NAVY), ("NeuralNet*", RED), ("Ensemble", GREY)]: ax.plot(tab.shift_bp, tab[col] - tab.true_dP, color=color, label=col)
ax.axhline(0, color="k", lw=.5); ax.set_xlabel("Shift (bp)"); ax.set_ylabel("Error vs full repricing"); ax.legend(frameon=False, fontsize=7, ncol=2); ax.set_title("Price-change error, 30-year bond"); save("f11_ml_err")
# F12 SHAP
sh = R["shap"]["NeuralNet*"]; feats = ["coupon_rate", "maturity", "yield_rate", "duration", "convexity"]; imp = sh["imp"]
fig, ax = plt.subplots(1, 2, figsize=(6.8, 3.2)); ks = list(imp); ax[0].barh(ks[::-1], [imp[k_] for k_ in ks][::-1], color=NAVY); ax[0].set_title("Mean |SHAP| (neural net)")
for j, f in enumerate(feats):
    xs = sh["Xe"][:, j]; xs = (xs - xs.min()) / (np.ptp(xs) + 1e-12); ax[1].scatter(sh["phi"][:, j], np.full(len(xs), j) + np.random.default_rng(j).normal(0, .07, len(xs)), c=xs, cmap="coolwarm", s=5)
ax[1].set_yticks(range(5)); ax[1].set_yticklabels(feats); ax[1].set_xlabel("SHAP value (price points)"); ax[1].set_title("Beeswarm (colour = feature value)"); save("f12_shap")
# F13 backtest
b = R["bt"]["normal"]; bh = R["bt"]["historical"]; fig, ax = plt.subplots(figsize=(6.6, 3.3)); a_ = b["act"][-750:] / cr
ax.plot(a_, color=GREY, lw=.6, label="Daily P&L"); ax.plot(-b["var"][-750:] / cr, color=NAVY, lw=1, label="99% VaR (delta-normal)"); ax.plot(-bh["var"][-750:] / cr, color=TEAL, lw=1, label="99% VaR (historical)")
br = np.flatnonzero(a_ < -b["var"][-750:] / cr); ax.scatter(br, a_[br], color=RED, s=12, zorder=5, label=f"Normal breaches ({len(br)})"); ax.set_xlabel("Day"); ax.set_ylabel("INR crore"); ax.legend(frameon=False, fontsize=7); ax.set_title("VaR back-test (synthetic fat-tailed history)"); save("f13_backtest")
# F14 barbell vs bullet
hb = R["hedge"]["table"]; fig, ax = plt.subplots(figsize=(6.6, 3.2)); xx = np.arange(len(hb)); ax.bar(xx - .2, hb.Barbell * 100, .4, color=NAVY, label="Barbell (2Y+30Y)"); ax.bar(xx + .2, hb.Bullet * 100, .4, color=ORG, label="Bullet (10Y)")
ax.set_xticks(xx); ax.set_xticklabels(hb.Scenario, rotation=20, ha="right", fontsize=7); ax.axhline(0, color="k", lw=.6); ax.set_ylabel("Return (%)"); ax.legend(frameon=False); ax.set_title("Same duration, different convexity"); save("f14_barbell")
# F15 perpetual and SEBI
yy = np.linspace(.05, .22, 100); fig, ax = plt.subplots(1, 2, figsize=(6.8, 3.1)); ax[0].plot(yy * 100, 1 / yy, color=NAVY, label="Modified duration 1/y"); ax[0].plot(yy * 100, 2 / yy ** 2 / 10, color=ORG, label="Convexity 2/y2 (/10)"); ax[0].legend(frameon=False, fontsize=7); ax[0].set_xlabel("Yield (%)"); ax[0].set_title("Perpetual bond measures")
sb = R["cs"]["sebi"]; ax[1].bar(sb.Years.astype(str) + "y", sb.ModDur, color=TEAL); ax[1].set_ylabel("Modified duration"); ax[1].set_title("AT1 deemed-maturity rule (8.5% par)"); save("f15_perp")
# F16 revenue
bm = R["bm"]; fig, ax = plt.subplots(figsize=(6.4, 3.2)); bot = np.zeros(5)
for col, lab, colr in [("bank_rev", "Bank treasuries", NAVY), ("ins_rev", "Insurance/pension", TEAL), ("retail_rev", "CFA/FRM retail", ORG), ("univ_rev", "Universities", GREY), ("cert_rev", "Certification", RED)]:
    ax.bar(bm.Year, bm[col] / cr, bottom=bot, color=colr, label=lab); bot += bm[col].to_numpy() / cr
ax.set_xlabel("Year"); ax.set_ylabel("Revenue (INR crore)"); ax.legend(frameon=False, fontsize=7); ax.set_title("Five-year revenue build"); save("f16_revenue")
# F17 architecture diagram
fig, ax = plt.subplots(figsize=(6.8, 3.9)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 6)
def box(x, y, w, h, t, col):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05", fc=col, ec="none", alpha=.9)); ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", color="white", fontsize=7.5, wrap=True)
box(.2, 4.4, 2.8, 1.2, "Data layer\nCCIL / FIMMDA / RBI\n300-bond book", NAVY); box(3.6, 4.4, 2.8, 1.2, "Analytics engine\nPrice, D, C, DV01, KRD", NAVY); box(7, 4.4, 2.8, 1.2, "Scenario injector\nRoutine / curve / credit / crisis", NAVY)
box(.2, 2.4, 2.8, 1.2, "Monte Carlo module\n3-factor, VaR / ES", TEAL); box(3.6, 2.4, 2.8, 1.2, "ML workbench\nRF / GBM / NN + SHAP", TEAL); box(7, 2.4, 2.8, 1.2, "Yield-curve simulator\nNS / Svensson", TEAL)
box(.2, .4, 2.8, 1.2, "Scoring engine\n1,000-point rubric", ORG); box(3.6, .4, 2.8, 1.2, "Learning layer\nformula + code + reference", ORG); box(7, .4, 2.8, 1.2, "Progression + badges\n7 levels, 20 badges", ORG)
for x in (1.6, 5.0, 8.4):
    ax.annotate("", (x, 3.7), (x, 4.35), arrowprops=dict(arrowstyle="->", color=GREY)); ax.annotate("", (x, 1.7), (x, 2.35), arrowprops=dict(arrowstyle="->", color=GREY))
ax.set_title("Bond Risk Lab architecture", fontsize=10); save("f17_arch")
# F18 sens twist vs conv (MC convergence)
mcv = R["mc_conv"]; fig, ax = plt.subplots(figsize=(6.2, 3)); ax.semilogx(mcv.n, mcv.VaR95 / cr, "o-", color=NAVY, label="VaR95"); ax.semilogx(mcv.n, mcv.VaR99 / cr, "s-", color=RED, label="VaR99"); ax.set_xlabel("Number of scenarios"); ax.set_ylabel("INR crore"); ax.legend(frameon=False); ax.set_title("Monte Carlo convergence"); save("f18_conv")
# equations
EQ = {
 "eq_price": r"$P=\sum_{i=1}^{N}\frac{CF_i}{(1+y/f)^{f\,t_i}}$",
 "eq_mac": r"$D_{Mac}=\frac{1}{P}\sum_{i=1}^{N} t_i\,PV(CF_i)$",
 "eq_mod": r"$D_{Mod}=\frac{D_{Mac}}{1+y/f}=-\frac{1}{P}\frac{\partial P}{\partial y}$",
 "eq_eff": r"$D_{eff}=\frac{P_{-}-P_{+}}{2\,P_0\,\Delta y},\qquad C_{eff}=\frac{P_{-}+P_{+}-2P_0}{P_0\,(\Delta y)^2}$",
 "eq_krd": r"$KRD_k=-\frac{P(y_k+\delta)-P(y_k-\delta)}{2\,P_0\,\delta}, \qquad \sum_k KRD_k\approx D_{eff}$",
 "eq_dv01": r"$DV01=D_{Mod}\times P\times 10^{-4}, \qquad DV01_{port}=\sum_j q_j\,DV01_j$",
 "eq_conv": r"$C=\frac{1}{P}\frac{\partial^2 P}{\partial y^2}=\frac{1}{P\,f^{2}(1+y/f)^{2}}\sum_{i} k_i(k_i+1)\,PV(CF_i),\quad k_i=f\,t_i$",
 "eq_taylor": r"$\frac{\Delta P}{P}\approx -D_{Mod}\,\Delta y+\frac{1}{2}\,C\,(\Delta y)^2$",
 "eq_pnl3": r"$\Delta V\approx -\sum_{k}\mathrm{KRD}_k\,\Delta y_k\,V+\frac{1}{2}\,C_{port}\,(\Delta y_{\parallel})^{2}V,\quad \Delta y_k=\ell+s\,g_k+b\,h_k$",
 "eq_var": r"$\mathrm{VaR}_\alpha=-q_{1-\alpha}(\Delta V),\qquad \mathrm{ES}_\alpha=-\mathbb{E}\left[\Delta V\mid \Delta V\leq q_{1-\alpha}\right]$",
 "eq_param": r"$\mathrm{VaR}^{param}_\alpha=V\,D_{Mod}\,z_\alpha\,\sigma_y\sqrt{h},\qquad \mathrm{ES}^{param}_\alpha=V\,D_{Mod}\,\sigma_y\sqrt{h}\,\frac{\varphi(z_\alpha)}{1-\alpha}$",
 "eq_chol": r"$\mathbf{F}=\mathbf{Z}\,L^{\top}\,\mathrm{diag}(\sigma),\quad LL^{\top}=\Sigma_{corr}$",
 "eq_ns": r"$y(\tau)=\beta_0+\beta_1\frac{1-e^{-\tau/\lambda}}{\tau/\lambda}+\beta_2\left(\frac{1-e^{-\tau/\lambda}}{\tau/\lambda}-e^{-\tau/\lambda}\right)$",
 "eq_sv": r"$y(\tau)=NS(\tau)+\beta_3\left(\frac{1-e^{-\tau/\lambda_2}}{\tau/\lambda_2}-e^{-\tau/\lambda_2}\right)$",
 "eq_boot": r"$z_n=f\left[\left(\frac{100+c/f}{P_n-\sum_{i<n}\frac{c/f}{(1+z_i/f)^{i}}}\right)^{1/n}-1\right]$",
 "eq_fwd": r"$f(t_1,t_2)=\left[\frac{(1+z_2/f)^{f t_2}}{(1+z_1/f)^{f t_1}}\right]^{\frac{1}{f(t_2-t_1)}}-1$",
 "eq_perp": r"$P=\frac{c}{y},\quad D_{Mac}=\frac{1+y}{y},\quad D_{Mod}=\frac{1}{y},\quad C=\frac{2}{y^{2}}$",
 "eq_kupiec": r"$LR_{POF}=-2\ln\left[\frac{(1-p)^{N-x}p^{x}}{(1-x/N)^{N-x}(x/N)^{x}}\right]\sim\chi^{2}_{1}$",
 "eq_shap": r"$\phi_j=\sum_{S\subseteq F\setminus\{j\}}\frac{|S|!\,(d-|S|-1)!}{d!}\left[v(S\cup\{j\})-v(S)\right]$",
 "eq_rmse": r"$RMSE=\sqrt{\frac{1}{n}\sum_{i}(\hat P_i-P_i)^2},\qquad R^{2}=1-\frac{\sum(\hat P_i-P_i)^2}{\sum(P_i-\bar P)^2}$",
 "eq_immun": r"$N_{swap}=\frac{DV01_{target}-DV01_{port}}{DV01_{swap}}$",
}
for k_, s_ in EQ.items():
    fig = plt.figure(figsize=(6, .7)); fig.text(.5, .5, s_, ha="center", va="center", fontsize=13); plt.savefig(O + k_ + ".png", dpi=200, bbox_inches="tight", pad_inches=.06, transparent=False, facecolor="white"); plt.close()
print("figs ok")
