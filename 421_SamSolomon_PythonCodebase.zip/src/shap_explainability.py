"""shap_explainability.py - SHAP values for the best pricing model.

* If the `shap` package is importable the standard TreeExplainer path is used.
* Otherwise exact interventional Shapley values are computed by enumerating all 2^d feature
  coalitions (d = 5, 32 coalitions) against a background sample - the quantity that
  shap.KernelExplainer approximates. Local accuracy is verified: sum(phi) + E[f] = f(x).
"""
from __future__ import annotations
from itertools import combinations
from math import factorial
import numpy as np


def exact_shapley(predict, X_explain: np.ndarray, X_background: np.ndarray):
    n, d = X_explain.shape
    m = X_background.shape[0]
    values = {}                                                    # coalition mask -> (n,) value
    for mask_int in range(2 ** d):
        mask = np.array([(mask_int >> j) & 1 for j in range(d)], dtype=bool)
        # rows: every explained point crossed with every background point
        Z = np.repeat(X_background[None, :, :], n, axis=0).copy()   # (n, m, d)
        Z[:, :, mask] = X_explain[:, None, mask]
        values[mask_int] = predict(Z.reshape(-1, d)).reshape(n, m).mean(axis=1)
    phi = np.zeros((n, d))
    for j in range(d):
        others = [k for k in range(d) if k != j]
        for r in range(d):
            w = factorial(r) * factorial(d - r - 1) / factorial(d)
            for S in combinations(others, r):
                s_int = sum(1 << k for k in S)
                phi[:, j] += w * (values[s_int | (1 << j)] - values[s_int])
    base = values[0]
    return phi, base, values[2 ** d - 1]


def explain(model, X_test, X_train, features, n_explain=300, n_background=60, seed=0):
    rng = np.random.default_rng(seed)
    Xe = X_test.sample(n_explain, random_state=seed)[features].to_numpy()
    Xb = X_train.sample(n_background, random_state=seed)[features].to_numpy()
    try:
        import shap                                                 # preferred path
        explainer = shap.TreeExplainer(model)
        return explainer.shap_values(Xe), explainer.expected_value, Xe
    except Exception:
        phi, base, fx = exact_shapley(lambda A: model.predict(A), Xe, Xb)
        assert np.allclose(phi.sum(axis=1) + base, fx, atol=1e-6), "local accuracy violated"
        return phi, float(base.mean()), Xe


def global_importance(phi, features):
    imp = np.abs(phi).mean(axis=0)
    return dict(sorted(zip(features, imp), key=lambda kv: -kv[1]))
