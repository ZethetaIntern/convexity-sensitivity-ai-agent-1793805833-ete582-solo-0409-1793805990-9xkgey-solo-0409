import pickle, datetime as dt, numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from bond_pricing import *
from yield_curve import ns_curve
R = pickle.load(open("../out/results.pkl", "rb"))
wb = Workbook(); H = Font(bold=True, color="FFFFFF"); F = PatternFill("solid", fgColor="1F3864")
def hdr(ws, row, cols):
    for i, c in enumerate(cols, 1):
        x = ws.cell(row, i, c); x.font = H; x.fill = F
# Tab1 pricing -------------------------------------------------------------------
ws = wb.active; ws.title = "1_Pricing"
ws["A1"] = "Bond pricing validation: Excel PRICE/DURATION/MDURATION vs Python (settlement 6-Feb-2024, basis 0 = 30/360, freq 2)"
hdr(ws, 3, ["Bond", "Coupon", "YTM", "Settlement", "Maturity", "Excel PRICE", "Python price", "Abs diff", "Excel DURATION", "Python MacD", "Abs diff", "Excel MDURATION", "Python ModD", "Abs diff"])
r = 4
for nm, c, y, n in R["val_bonds"]:
    mat = dt.date(2024 + n, 2, 6)
    ws.append([nm, c, y, dt.date(2024, 2, 6), mat, f"=PRICE(D{r},E{r},B{r},C{r},100,2,0)", bond_price(100, c, y, n), f"=ABS(F{r}-G{r})",
               f"=DURATION(D{r},E{r},B{r},C{r},2,0)", macaulay_duration(100, c, y, n), f"=ABS(I{r}-J{r})", f"=MDURATION(D{r},E{r},B{r},C{r},2,0)",
               modified_duration(100, c, y, n), f"=ABS(L{r}-M{r})"]); r += 1
# zero-coupon T-bill (closed form, no PRICE equivalent)
ws.append(["91-day T-Bill (zero)", 0, 0.065, None, None, "=100/(1+C8/2)^(2*91/365)", bond_price(100, 0, .065, 91 / 365), f"=ABS(F{r}-G{r})", "=91/365", macaulay_duration(100, 0, .065, 91 / 365), f"=ABS(I{r}-J{r})", f"=I{r}/(1+C{r}/2)", modified_duration(100, 0, .065, 91 / 365), f"=ABS(L{r}-M{r})"])
# Tab2 ladder ----------------------------------------------------------------------
w2 = wb.create_sheet("2_Convexity"); w2["A1"] = "7.26% GOI 2033 cash-flow ladder: price, Macaulay, modified duration, convexity, DV01 (all formula-driven)"
w2["A2"], w2["B2"], w2["C2"], w2["D2"] = "Coupon", 0.0726, "YTM", 0.0735
hdr(w2, 4, ["Period k", "Time (yrs)", "Cash flow", "PV", "t x PV", "k(k+1) x PV"])
for k in range(1, 19):
    rr = 4 + k
    w2.append([k, f"=A{rr}/2", f"=100*$B$2/2+IF(A{rr}=18,100,0)", f"=C{rr}/(1+$D$2/2)^A{rr}", f"=B{rr}*D{rr}", f"=A{rr}*(A{rr}+1)*D{rr}"])
w2["H4"], w2["I4"], w2["J4"] = "Metric", "Excel (ladder)", "Python"
vals = R["ex1"]
rows = [("Price", "=SUM(D5:D22)", vals["P"]), ("Macaulay", "=SUM(E5:E22)/I5", vals["MacD"]), ("Modified", "=I6/(1+D2/2)", vals["ModD"]),
        ("Convexity", "=SUM(F5:F22)/(I5*4*(1+D2/2)^2)", vals["Conv"]), ("DV01 / 100 face", "=I7*I5/10000", vals["DV01"])]
for i, (a, f, p) in enumerate(rows):
    w2.cell(5 + i, 8, a); w2.cell(5 + i, 9, f); w2.cell(5 + i, 10, p)
# Tab3 portfolio ---------------------------------------------------------------------
w3 = wb.create_sheet("3_Portfolio"); w3["A1"] = "3-bond portfolio aggregation cross-check"
hdr(w3, 3, ["Bond", "ModDur", "Convexity", "DV01/100", "Price", "Qty", "MV", "Weight"])
for i, b in enumerate(R["ex2"]["table"].itertuples()):
    rr = 4 + i; w3.append([b.Bond, b.ModDur, b.Conv, b.DV01, b.Price, b.Qty, f"=E{rr}*F{rr}", f"=G{rr}/$G$7"])
w3["F7"] = "Total MV"; w3["G7"] = "=SUM(G4:G6)"
for i, (lab, f) in enumerate([("Portfolio ModDur", "=SUMPRODUCT(B4:B6,H4:H6)"), ("Portfolio Convexity", "=SUMPRODUCT(C4:C6,H4:H6)"), ("Portfolio DV01 (INR)", "=SUMPRODUCT(D4:D6,F4:F6)"),
                              ("Duration P&L +100bp", "=-B9*0.01*G7"), ("Convexity P&L +100bp", "=0.5*B10*0.01^2*G7"), ("Net P&L +100bp", "=B12+B13")]):
    w3.cell(9 + i, 1, lab); w3.cell(9 + i, 2, f)
# Tab4 VaR ----------------------------------------------------------------------------
w4 = wb.create_sheet("4_VaR"); w4["A1"] = "Parametric VaR (delta-normal) vs Monte Carlo (values pasted from Python run, seed 11, 100k draws)"
for i, (lab, v) in enumerate([("MV", "='3_Portfolio'!G7"), ("ModDur", "='3_Portfolio'!B9"), ("Daily yield vol", 0.0006), ("z95", "=NORMSINV(0.95)"), ("z99", "=NORMSINV(0.99)"),
                              ("Parametric VaR95", "=B3*B4*B6*B5"), ("Parametric VaR99", "=B3*B4*B7*B5")]):
    w4.cell(3 + i, 1, lab); w4.cell(3 + i, 2, v)
e3 = R["ex3"]; w4["A12"], w4["B12"] = "MC VaR95 (Python)", e3["mc95"]; w4["A13"], w4["B13"] = "MC VaR99 (Python)", e3["mc99"]
w4["A14"], w4["B14"] = "Diff VaR95 %", "=B12/B8-1"; w4["A15"], w4["B15"] = "Diff VaR99 %", "=B13/B9-1"
# Tab5 Nelson-Siegel ---------------------------------------------------------------------
w5 = wb.create_sheet("5_NelsonSiegel"); w5["A1"] = "Nelson-Siegel fitted vs observed (parameters from scipy least_squares)"
p = R["yc"]["ns_p"]
for i, (n_, v) in enumerate(zip(["b0", "b1", "b2", "lambda"], p)): w5.cell(2, 2 + 2 * i, n_); w5.cell(2, 3 + 2 * i, float(v))
hdr(w5, 4, ["Tenor", "Observed", "Fitted (Excel formula)", "Error (bp)"])
for i, (t, y) in enumerate(zip(R["yc"]["table"].Tenor, R["yc"]["obs"])):
    rr = 5 + i
    w5.append([float(t), float(y), f"=$C$2+$E$2*((1-EXP(-A{rr}/$I$2))/(A{rr}/$I$2))+$G$2*((1-EXP(-A{rr}/$I$2))/(A{rr}/$I$2)-EXP(-A{rr}/$I$2))", f"=(C{rr}-B{rr})*10000"])
w5["F4"], w5["G4"] = "R-squared", "=1-SUMXMY2(B5:B15,C5:C15)/DEVSQ(B5:B15)"
wb.save("../out/421_SamSolomon_ValidationWorkbook.xlsx")
