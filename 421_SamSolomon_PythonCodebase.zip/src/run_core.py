"""run_core.py - executes every analysis quoted in the report and stores results in out/results.pkl"""
import pickle, sys, numpy as np, pandas as pd
from scipy.optimize import brentq
from scipy.stats import norm
from bond_pricing import *
from portfolio_analytics import *
from monte_carlo import BondRiskMC
from yield_curve import *
from var_backtest import *
from sensitivity_analysis import *
from shap_explainability import exact_shapley, global_importance
import ml_models as mlm

R = {}
# ------------------------------------------------------------------ A: worked example 1
c, y, n = 0.0726, 0.0735, 9
P = bond_price(100, c, y, n); MD = modified_duration(100, c, y, n); CV = convexity(100, c, y, n)
MacD = macaulay_duration(100, c, y, n); DV = dv01(100, c, y, n)
t, cf = cash_flows(100, c, n); pv = cf / (1 + y / 2) ** (2 * t)
k = 2 * t
ex1 = dict(P=P, MacD=MacD, ModD=MD, Conv=CV, DV01=DV, pv_coupons=float(pv[:-1].sum() + (pv[-1] - 100 / (1 + y / 2) ** 18)),
           pv_principal=100 / (1 + y / 2) ** 18, sum_t_pv=float((t * pv).sum()), sum_kk1_pv=float((k * (k + 1) * pv).sum()),
           first_rows=[(float(a), float(b), float(d)) for a, b, d in zip(t[:3], cf[:3], pv[:3])], last_row=(float(t[-1]), float(cf[-1]), float(pv[-1])))
for dy_bp in (100, -100, 200, 300):
    dy = dy_bp / 1e4
    d_eff, c_eff, est = price_change_estimate(P, MD, CV, dy)
    ex1[f"est_{dy_bp}"] = dict(dur=d_eff, conv=c_eff, est=est, true=bond_price(100, c, y + dy, n))
R["ex1"] = ex1

# ------------------------------------------------------------------ A: worked example 2 (3-bond book)
bonds = [("GOI 7.26% 2033", 0.0726, 0.0735, 9, 5000), ("AAA 8.50% 2027", 0.0850, 0.0820, 3, 3000),
         ("GOI 6.10% 2054", 0.0610, 0.0640, 30, 2000)]
rows = []
for nm, cc, yy, nn, q in bonds:
    p = bond_price(100, cc, yy, nn)
    rows.append(dict(Bond=nm, Coupon=cc, YTM=yy, Years=nn, Qty=q, Price=p, ModDur=modified_duration(100, cc, yy, nn),
                     Conv=convexity(100, cc, yy, nn), DV01=dv01(100, cc, yy, nn), MV=p * q))
b3 = pd.DataFrame(rows); b3["Weight"] = b3.MV / b3.MV.sum()
tot = b3.MV.sum(); pd_ = (b3.Weight * b3.ModDur).sum(); pc_ = (b3.Weight * b3.Conv).sum(); pdv = (b3.DV01 * b3.Qty).sum()


def reprice_3(shift_fn):
    out = 0.0
    for r in b3.itertuples():
        tt, cff = cash_flows(100, r.Coupon, r.Years)
        out += r.Qty * np.sum(cff / (1 + (r.YTM + shift_fn(tt)) / 2) ** (2 * tt))
    return out - tot


par = dict(Level=pd_, Conv=pc_, Tot=tot, DV01=pdv)
sc3 = {}
for bp in (100, -100):
    dy = bp / 1e4
    sc3[f"par{bp}"] = dict(dur=-pd_ * dy * tot, conv=0.5 * pc_ * dy ** 2 * tot, full=reprice_3(lambda tt: dy * np.ones_like(tt)))
shift_pts = ([2, 10, 30], [0.0080, 0.0050, 0.0030])        # steepening-flattening as in brief: 2Y +80, 10Y +50, 30Y +30
fn = lambda tt: np.interp(tt, shift_pts[0], shift_pts[1])
krd3 = {}
for r in b3.itertuples():
    tt, cff = cash_flows(100, r.Coupon, r.Years); base = np.sum(cff / (1 + r.YTM / 2) ** (2 * tt)); v = []
    for kk in range(len(KEY_TENORS)):
        h = hat(tt, kk) * 1e-4
        v.append(-(np.sum(cff / (1 + (r.YTM + h) / 2) ** (2 * tt)) - np.sum(cff / (1 + (r.YTM - h) / 2) ** (2 * tt))) / (2 * base * 1e-4))
    krd3[r.Bond] = np.array(v)
pnl_krd = sum(-(krd3[r.Bond] * np.interp(KEY_TENORS, shift_pts[0], shift_pts[1])).sum() * r.MV for r in b3.itertuples())
sc3["nonpar"] = dict(krd=pnl_krd, full=reprice_3(fn), parallel50=-pd_ * 0.005 * tot + 0.5 * pc_ * 0.005 ** 2 * tot)
inv = lambda tt: np.interp(tt, [2, 10, 30], [0.01, -0.0025, -0.0025])
sc3["flat_inv"] = dict(full=reprice_3(inv))
R["ex2"] = dict(table=b3, port=par, scen=sc3, krd3={k_: v_.tolist() for k_, v_ in krd3.items()})

# ------------------------------------------------------------------ A: VaR example (parametric, per brief inputs)
mv, md_, cv_ = tot, pd_, pc_
R["ex3"] = dict(mv=mv, md=md_, var95=mv * md_ * norm.ppf(.95) * 0.0006, var99=mv * md_ * norm.ppf(.99) * 0.0006,
                var95_10=mv * md_ * norm.ppf(.95) * 0.0006 * np.sqrt(10), var99_10=mv * md_ * norm.ppf(.99) * 0.0006 * np.sqrt(10),
                cvar95=mv * md_ * 0.0006 * norm.pdf(norm.ppf(.95)) / 0.05, cvar99=mv * md_ * 0.0006 * norm.pdf(norm.ppf(.99)) / 0.01)
rng = np.random.default_rng(11)
dy_s = rng.normal(0, 0.0006, 100_000); pl = -md_ * dy_s * mv + 0.5 * cv_ * dy_s ** 2 * mv
R["ex3"].update(mc95=-np.percentile(pl, 5), mc99=-np.percentile(pl, 1), mc_es95=-pl[pl <= np.percentile(pl, 5)].mean(), mc_es99=-pl[pl <= np.percentile(pl, 1)].mean())

# ------------------------------------------------------------------ A: duration/convexity table for instruments & price-yield curve
inst = [("91-day T-Bill", 0.0, .065, .25), ("364-day T-Bill", 0.0, .066, 1.0), ("7.26% GOI 2033", .0726, .0735, 9), ("7.54% GOI 2036", .0754, .0745, 12),
        ("6.10% GOI 2054", .0610, .0640, 30), ("AAA Corp 3Y 8.0%", .08, .0760, 3), ("AA Corp 5Y 9.0%", .09, .0870, 5)]
R["inst"] = pd.DataFrame([dict(Instrument=a, Coupon=b, YTM=cc, Years=d, Price=bond_price(100, b, cc, d), ModDur=modified_duration(100, b, cc, d),
                               Conv=convexity(100, b, cc, d), ConvImpact100=0.5 * convexity(100, b, cc, d) * 1e-4 * 100) for a, b, cc, d in inst])

# ------------------------------------------------------------------ Excel-style validation helper (values for xlsx comparison)
R["val_bonds"] = [("GOI 7.26% 2033", .0726, .0735, 9), ("GOI 7.54% 2036", .0754, .0745, 12), ("GOI 6.10% 2054", .0610, .0640, 30),
                  ("AAA 8.50% 2027", .0850, .0820, 3)]

# ------------------------------------------------------------------ 300-bond portfolio
df = build_portfolio(); book = BookRepricer(df); S = portfolio_summary(df)
kmat, pk = portfolio_krd(book)
R["pf"] = dict(df=df, S=S, pk=pk, kmat=kmat, by_rating=contribution(df, "CreditRating"), by_ccy=contribution(df, "Currency"),
               by_sector=contribution(df, "Sector"), by_bucket=contribution(df, "KeyRateBucket").reindex([b for b in KEY_LABELS if b in set(df.KeyRateBucket)]),
               by_seg=contribution(df, "Segment"))
seg_krd = pd.DataFrame({sg: (df.loc[df.Segment == sg, "PortfolioWeight"].to_numpy()[:, None] * kmat[(df.Segment == sg).to_numpy()]).sum(axis=0) for sg in df.Segment.unique()}, index=KEY_LABELS).T
R["pf"]["seg_krd"] = seg_krd
# parallel scenarios
rows = []
for bp in (25, 50, 100, 200, 300, -100):
    dy = bp / 1e4; d, cvx, tot_ = duration_convexity_pnl(S, dy); full = book.pnl(book.factor_shock(level_bp=bp, scale_by_ccy=False))
    rows.append(dict(shift=bp, dur=d, conv=cvx, dur_conv=tot_, full=full, conv_pct_of_dur=cvx / abs(d)))
R["par_scen"] = pd.DataFrame(rows)
# multi-factor stress matrix (A6.3)
stress = [("Base Case", 0, 0, 0), ("RBI Hike (Expected)", 25, 0, 0), ("RBI Surprise Hike", 50, -20, 5), ("Global Risk-Off", 75, 30, -10),
          ("Dovish Pivot", -75, -20, 5), ("Credit Crisis", 100, 50, -20), ("Stagflation", 150, 25, 10), ("Black Swan", 300, 75, -30)]
rows = []
for nme, a, b, cc in stress:
    sh = book.factor_shock(a, b, cc, scale_by_ccy=False)
    shf = np.interp(KEY_TENORS, TENORS, np.zeros(11))  # placeholder
    krd_pnl = -(((a * level_shape(KEY_TENORS) + b * twist_shape(KEY_TENORS) + cc * butterfly_shape(KEY_TENORS)) / 1e4) * (book.base_mv[:, None] * kmat).sum(axis=0)).sum()
    rows.append(dict(Scenario=nme, Parallel=a, Twist=b, Butterfly=cc, KRD_first=krd_pnl, Full=book.pnl(sh)))
R["stress"] = pd.DataFrame(rows)

# ------------------------------------------------------------------ Monte Carlo
mc_d = BondRiskMC(book, 10_000, seed=42); mc_d.generate_scenarios(horizon_days=1); mc_d.compute_pnl(full_reval=True, n_full=10_000)
mc_a = BondRiskMC(book, 10_000, seed=42); mc_a.generate_scenarios(horizon_days=252); mc_a.compute_pnl(full_reval=True, n_full=10_000)
R["mc"] = dict(daily={k_: mc_d.report(k_) for k_ in mc_d.pnl}, annual={k_: mc_a.report(k_) for k_ in mc_a.pnl},
               par_var95=mc_d.parametric_var(.95), par_var99=mc_d.parametric_var(.99), par_var95_a=mc_a.parametric_var(.95), par_var99_a=mc_a.parametric_var(.99),
               pnl_daily=mc_d.pnl, pnl_annual=mc_a.pnl, factors_daily=mc_d.factors_bp, vols=mc_d.vols_bp,
               corr_realised=np.corrcoef(mc_d.factors_bp.T))
# convergence with n
conv_rows = []
for nn_ in (500, 1000, 5000, 10000, 50000, 200000):
    m = BondRiskMC(book, nn_, seed=5); m.generate_scenarios(horizon_days=1); m.compute_pnl(full_reval=False)
    p = m.pnl["krd_first_order"]; conv_rows.append(dict(n=nn_, VaR95=m.var(p, .95), VaR99=m.var(p, .99), ES95=m.es(p, .95)))
R["mc_conv"] = pd.DataFrame(conv_rows)
# normal vs fat tail
mt = BondRiskMC(book, 100_000, seed=8); mt.generate_scenarios(horizon_days=1, dist="t"); mt.compute_pnl(full_reval=False)
mn = BondRiskMC(book, 100_000, seed=8); mn.generate_scenarios(horizon_days=1); mn.compute_pnl(full_reval=False)
R["mc_tail"] = {nm_: {kk: mm.report("krd_first_order")[kk] for kk in ("VaR95", "VaR99", "ES95", "ES99")} for nm_, mm in (("Normal", mn), ("Student-t(5)", mt))}
# twist vol sensitivity (parallel-only vs 3-factor), daily
tv = []
for tw in (3, 5, 7, 10):
    m = BondRiskMC(book, 20_000, seed=21); m.generate_scenarios(vol_twist_bp=tw * np.sqrt(252), horizon_days=1)  # tw = DAILY bp
    m.compute_pnl(full_reval=False)
    tv.append(dict(twist_bp_daily=tw, VaR95_3f=m.var(m.pnl["krd_first_order"], .95), VaR99_3f=m.var(m.pnl["krd_first_order"], .99),
                   VaR95_par=m.var(m.pnl["duration_convexity"], .95)))
R["twist_sens"] = pd.DataFrame(tv)

# ------------------------------------------------------------------ Backtest (synthetic daily history; illustrative)
rng = np.random.default_rng(2026); T_ = 1000
vol_path = 6.3 * np.exp(0.35 * np.cumsum(rng.normal(0, 0.06, T_)) - 0.35 ** 2 * 0)  # slow stochastic vol
vol_path = np.clip(vol_path, 3, 20)
z = rng.standard_t(4, T_) / np.sqrt(2.0)
dy_hist = z * vol_path / 1e4
pnl_hist = -S["mod_dur"] * dy_hist * S["total_mv_inr"] + 0.5 * S["convexity"] * dy_hist ** 2 * S["total_mv_inr"]
bt = {}
for method in ("historical", "normal"):
    act, vr = rolling_var_backtest(pnl_hist, 250, .99, "historical" if method == "historical" else "normal")
    nb = breaches(act[-750:], vr[-750:]); lr, pv_ = kupiec_pof(nb, 750, .99)
    last250 = breaches(act[-250:], vr[-250:])
    bt[method] = dict(n_breaches=nb, expected=7.5, LR=lr, p=pv_, last250=last250, zone=basel_zone(last250), act=act, var=vr)
for method in ("historical", "normal"):                      # 95%
    act, vr = rolling_var_backtest(pnl_hist, 250, .95, "historical" if method == "historical" else "normal")
    nb = breaches(act[-750:], vr[-750:]); lr, pv_ = kupiec_pof(nb, 750, .95)
    bt[method + "95"] = dict(n_breaches=nb, expected=37.5, LR=lr, p=pv_)
R["bt"] = bt; R["dy_hist"] = dy_hist

# ------------------------------------------------------------------ Yield curve
rng = np.random.default_rng(3)
y_obs = np.array(CURVES["INR"]) / 100 + rng.normal(0, 0.00015, 11)
ns_p, ns_f = fit_nelson_siegel(TENORS, y_obs); sv_p, sv_f = fit_svensson(TENORS, y_obs)
mats = np.arange(.5, 10.01, .5); zt = ns_curve(mats, *ns_p); dfs = discount_factor(zt, mats); parc = 2 * (1 - dfs) / np.cumsum(dfs)
prices = [100 * parc[i] / 2 * dfs[:i + 1].sum() + 100 * dfs[i] for i in range(len(mats))]
mb, zb = bootstrap_zero_curve(mats, parc, prices)
fwd = [(a, b, float(forward_rate(ns_curve(a, *ns_p), a, ns_curve(b, *ns_p), b))) for a, b in ((1, 2), (2, 5), (5, 10), (10, 20))]
fac = np.vstack([level_shape(TENORS), twist_shape(TENORS), butterfly_shape(TENORS)])
rng = np.random.default_rng(5); sim = rng.multivariate_normal([0, 0, 0], np.diag([6.3, 3.1, 1.9]) ** 2, 750) @ fac + rng.normal(0, 0.4, (750, 11))
pcs, pcv, _ = pca_factors(sim)
R["yc"] = dict(obs=y_obs, ns_p=ns_p, ns_f=ns_f, ns_s=fit_stats(y_obs, ns_f), sv_p=sv_p, sv_f=sv_f, sv_s=fit_stats(y_obs, sv_f), boot_err_bp=float(np.abs(zb - zt).max() * 1e4),
               fwd=fwd, pca_var=pcv, pca_load=pcs, zero_bootstrap=(mb, zb), table=pd.DataFrame(dict(Tenor=TENORS, Yield=y_obs, Zero=ns_f,
                                                                                                    DF=discount_factor(ns_f, TENORS))))
# ------------------------------------------------------------------ ML
res = pickle.load(open("../out/ml.pkl", "rb"))
R["ml"] = {k_: v_[1] for k_, v_ in res.items()}
fitted, _ = res["full"]
dfm = mlm.make_dataset(); from sklearn.model_selection import train_test_split
X_tr, X_te, y_tr, y_te = train_test_split(dfm[mlm.FEATURES_FULL], dfm["price"], test_size=0.2, random_state=42)
from sklearn.inspection import permutation_importance
R["perm"] = {}
for nm_, m in fitted.items():
    pi = permutation_importance(m, X_te.iloc[:1500], y_te.iloc[:1500], n_repeats=5, random_state=0)
    R["perm"][nm_] = dict(zip(mlm.FEATURES_FULL, pi.importances_mean))
shap_out = {}
for nm_ in ("RandomForest", "NeuralNet*"):
    m = fitted[nm_]
    Xe = X_te.sample(200, random_state=1)[mlm.FEATURES_FULL].to_numpy(); Xb = X_tr.sample(50, random_state=1)[mlm.FEATURES_FULL].to_numpy()
    phi, base, fx = exact_shapley(lambda A: m.predict(pd.DataFrame(A, columns=mlm.FEATURES_FULL)), Xe, Xb)
    shap_out[nm_] = dict(phi=phi, base=base, fx=fx, Xe=Xe, imp=global_importance(phi, mlm.FEATURES_FULL), maxerr=float(np.abs(phi.sum(1) + base - fx).max()))
R["shap"] = shap_out
sens = {}
for tag, (cc, yrs, y0) in {"GOI2033": (.0726, 9, .0735), "Long30Y": (.0610, 30, .0710)}.items():
    tab = sensitivity_table(cc, yrs, y0, fitted, mlm.FEATURES_FULL)
    models = list(fitted); w = {m_: 1 / R["ml"]["full"].set_index("Model").loc[m_, "Test_RMSE"] for m_ in models}
    tab = add_ensemble(tab, models, w); sens[tag] = (tab, error_summary(tab, models))
R["sens"] = sens

# ------------------------------------------------------------------ Hedging structures
mat_pts = {"2Y": 2, "10Y": 10, "30Y": 30}


def par_bond(Y, ccy="INR"):
    y_ = float(zero_rate(ccy, Y)); return dict(c=y_, y=y_, n=Y)


def stat(Y, w):
    pb = par_bond(Y); return w * modified_duration(100, pb["c"], pb["y"], Y), w * convexity(100, pb["c"], pb["y"], Y)


D_bullet = modified_duration(100, par_bond(10)["c"], par_bond(10)["y"], 10)
d2, d30 = [modified_duration(100, par_bond(Y)["c"], par_bond(Y)["y"], Y) for Y in (2, 30)]
w30 = (D_bullet - d2) / (d30 - d2); w2 = 1 - w30
bar_conv = w2 * convexity(100, par_bond(2)["c"], par_bond(2)["y"], 2) + w30 * convexity(100, par_bond(30)["c"], par_bond(30)["y"], 30)
bul_conv = convexity(100, par_bond(10)["c"], par_bond(10)["y"], 10)
lad = [2, 5, 7, 10, 15, 20, 30]


def rep_par(Y, shift_fn):
    pb = par_bond(Y); tt, cff = cash_flows(100, pb["c"], Y); return np.sum(cff / (1 + (pb["y"] + shift_fn(tt)) / 2) ** (2 * tt)) / 100 - 1


scen = {"Parallel +100": lambda tt: 0.01 * np.ones_like(tt), "Parallel -100": lambda tt: -0.01 * np.ones_like(tt),
        "Bull flattener (2Y 0, 30Y -75)": lambda tt: np.interp(tt, [2, 30], [0, -0.0075]), "Bear steepener (2Y +0, 30Y +75)": lambda tt: np.interp(tt, [2, 30], [0, 0.0075]),
        "Butterfly (5Y -30, wings 0)": lambda tt: -0.003 * np.exp(-((tt - 5) / 3) ** 2)}
hb = []
for nm_, f_ in scen.items():
    barb = w2 * rep_par(2, f_) + w30 * rep_par(30, f_); bul = rep_par(10, f_)
    hb.append(dict(Scenario=nm_, Barbell=barb, Bullet=bul, Diff=barb - bul))
R["hedge"] = dict(w2=w2, w30=w30, D_bullet=D_bullet, bar_conv=bar_conv, bul_conv=bul_conv, table=pd.DataFrame(hb))

# ------------------------------------------------------------------ Case-study numbers
cs = {}
# C1 RBI
y0, y1 = 0.06838, 0.07318            # 10Y benchmark at 31-Mar-2022 (derived from Reuters: +48bp in FY23) and 31-Mar-2023
dy_real = y1 - y0
cats = [("Liquid", .3, .2), ("Short duration", 2.5, 9), ("Medium duration", 3.8, 22), ("Dynamic bond", 6.0, 55), ("Gilt", 8.0, 120), ("10Y constant dur", 10.0, 150)]
cs["rbi"] = pd.DataFrame([dict(Category=a, D=d, C=c_, Stress250_dur=-d * .025, Stress250_conv=.5 * c_ * .025 ** 2, Stress250_net=-d * .025 + .5 * c_ * .025 ** 2,
                               Real_dur=-d * dy_real, Real_conv=.5 * c_ * dy_real ** 2, Real_net=-d * dy_real + .5 * c_ * dy_real ** 2) for a, d, c_ in cats]).assign(Category=[x[0] for x in cats])
cs["rbi_meta"] = dict(dy_real=dy_real, passthrough=dy_real / 0.025)
# callable corporate during hikes: effective duration table
rows = []
for yy in (.05, .06, .07, .08, .09, .10, .11):
    f = lambda q: callable_price_bachelier(100, .08, q, 10, 3, 100.0)
    ed, ec = effective_duration_convexity(f, yy, 0.001); rows.append(dict(y=yy, callable=f(yy), straight=bond_price(100, .08, yy, 10), eff_dur=ed, eff_conv=ec,
                                                                       s_dur=modified_duration(100, .08, yy, 10), s_conv=convexity(100, .08, yy, 10)))
cs["callable"] = pd.DataFrame(rows)
# C2 SVB
htm_cost, htm_fv, afs_loss, equity = 91.3, 76.2, 2.5, 16.3
loss_pct = (htm_cost - htm_fv) / htm_cost
imp = []
for Cn in (-50, 0, 45):
    f = lambda dy: -6.2 * dy + 0.5 * Cn * dy ** 2 + loss_pct
    imp.append(dict(C=Cn, dy_bp=brentq(f, 0, .2) * 1e4))
cs["svb"] = dict(loss_pct=loss_pct, implied=pd.DataFrame(imp), brief_dur_loss=91 * 5.6 * .0525, brief_conv=91 * .5 * 45 * .0525 ** 2,
                 dur62_at_425=91.3 * 6.2 * .0425, dv01_mm=6.2 * 91.3e9 / 1e4 / 1e6, swap_notional_bn=6.2 * 91.3e9 / 1e4 / (8.0 * 1e-4 * 1e0) / 1e9 if False else None, equity=equity,
                 total_loss=htm_cost - htm_fv + afs_loss)
cs["svb"]["swap_notional_bn"] = (6.2 * 91.3e9 / 1e4) / (0.0008 * 1e3 / 1e3 * 1.0) / 1e9 * 0  # replaced below
dv01_book = 6.2 * 91.3e9 / 1e4                                             # USD per bp
sw = modified_duration(100, .0400, .0400, 10, 2) * 100 / 1e4               # 10y par swap fixed-leg DV01 per 100 notional (approx)
cs["svb"]["swap_notional_bn"] = dv01_book / (sw / 100) / 1e9
cs["svb"]["dv01_usd_mm"] = dv01_book / 1e6
# MBS extension illustration: 4.5y -> 7y effective duration => extra loss for +100bp
cs["svb"]["mbs_ext_extra_pct"] = (7.0 - 4.5) * 0.01
# C3 gilt rally
d3 = 0.07591 - 0.06013
cs["rally"] = pd.DataFrame([dict(Category=a, D=d, C=c_, dur_gain=d * d3, conv_bonus=.5 * c_ * d3 ** 2, total=d * d3 + .5 * c_ * d3 ** 2,
                                 brief250_bonus=.5 * c_ * .025 ** 2) for a, d, c_ in cats if a != "Liquid"] + [dict(Category="30Y only", D=14.0, C=285.0, dur_gain=14 * d3, conv_bonus=.5 * 285 * d3 ** 2,
                                 total=14 * d3 + .5 * 285 * d3 ** 2, brief250_bonus=.5 * 285 * .025 ** 2)])
cs["rally_meta"] = dict(d3=d3)
# asymmetry for +/-158bp on gilt fund
cs["asym"] = dict(up=-8.0 * d3 + .5 * 120 * d3 ** 2, down=8.0 * d3 + .5 * 120 * d3 ** 2)
# C4 perpetual
cs["perp"] = pd.DataFrame([dict(y=yy, mac=perpetual_metrics(yy)["mac_dur"], mod=perpetual_metrics(yy)["mod_dur"], conv=perpetual_metrics(yy)["convexity"],
                                conv100=.5 * perpetual_metrics(yy)["convexity"] * 1e-4 * 100) for yy in (.06, .08, .10, .12, .15, .20)])
y_a, y_b = .095, .13
cs["perp_scen"] = dict(mac_a=perpetual_metrics(y_a)["mac_dur"], mac_b=perpetual_metrics(y_b)["mac_dur"], mod_a=1 / y_a, mod_b=1 / y_b, c_a=2 / y_a ** 2, c_b=2 / y_b ** 2,
                       est=-(1 / y_a) * .035 + .5 * (2 / y_a ** 2) * .035 ** 2, exact=y_a / y_b - 1, exact20=y_a / .20 - 1,
                       est_dur_only=-(1 / y_a) * .035)
# SEBI deemed maturity
cs["sebi"] = pd.DataFrame([dict(Deemed=lab, Years=nn_, ModDur=modified_duration(100, .085, .085, nn_, 1), Conv=convexity(100, .085, .085, nn_, 1),
                                Px_plus100=bond_price(100, .085, .095, nn_, 1) - 100) for lab, nn_ in (("10 yr (to Mar-2022)", 10), ("20 yr (from Apr-2022)", 20), ("30 yr (from Oct-2022)", 30), ("100 yr (from Apr-2023)", 100))])
# Tata-style callable perpetual (illustrative): 9.0% coupon, call at yr 10, ~100y proxy
rows = []
for yy in (.07, .08, .09, .10, .11, .12, .13):
    f = lambda q: callable_price_bachelier(100, .09, q, 100, 10, 100.0, 1, 0.01)
    ed, ec = effective_duration_convexity(f, yy, 0.001)
    ytc = brentq(lambda q: bond_price(100, .09, q, 10, 1) - f(yy), -.1, 1.0)
    rows.append(dict(y=yy, price=f(yy), straight10=bond_price(100, .09, yy, 10, 1), perp=9.0 / (yy * 100) * 100, eff_dur=ed, eff_conv=ec))
cs["tata"] = pd.DataFrame(rows)
R["cs"] = cs

# ------------------------------------------------------------------ business model
bm = [dict(Year=1, banks=8, users_b=40, price_b=12000, ins=0, users_i=0, retail=500, univ=0, univ_fee=0, cert=0),
      dict(Year=2, banks=20, users_b=55, price_b=15000, ins=0, users_i=0, retail=2000, univ=5, univ_fee=300000, cert=0),
      dict(Year=3, banks=35, users_b=55, price_b=16000, ins=6, users_i=40, retail=8000, univ=20, univ_fee=300000, cert=0),
      dict(Year=4, banks=45, users_b=60, price_b=17000, ins=15, users_i=50, retail=20000, univ=50, univ_fee=350000, cert=1000),
      dict(Year=5, banks=50, users_b=60, price_b=16000, ins=25, users_i=40, retail=50000, univ=100, univ_fee=250000, cert=1000)]
for r_ in bm:
    r_["bank_rev"] = r_["banks"] * r_["users_b"] * r_["price_b"]; r_["ins_rev"] = r_["ins"] * r_["users_i"] * 15000
    r_["retail_rev"] = r_["retail"] * 4999; r_["univ_rev"] = r_["univ"] * r_["univ_fee"]; r_["cert_rev"] = r_["cert"] * 7999
    r_["total"] = r_["bank_rev"] + r_["ins_rev"] + r_["retail_rev"] + r_["univ_rev"] + r_["cert_rev"]
    r_["total_cr"] = r_["total"] / 1e7
    r_["total_half_retail"] = (r_["total"] - 0.5 * r_["retail_rev"]) / 1e7
R["bm"] = pd.DataFrame(bm)

pickle.dump(R, open("../out/results.pkl", "wb"))
print("done", S)
