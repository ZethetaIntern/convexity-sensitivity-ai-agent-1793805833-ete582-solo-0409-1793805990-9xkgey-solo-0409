"""monte_carlo.py - BondRiskMC: correlated 3-factor (level / twist / butterfly) yield-curve
Monte Carlo with first-order (KRD), second-order (duration-convexity) and full-revaluation P&L,
plus VaR / Expected Shortfall.

Sign convention: P&L > 0 is a gain. VaR and ES are reported as POSITIVE loss amounts.
Volatilities are ANNUAL (bp); `horizon_days` scales them by sqrt(h/252).
"""
from __future__ import annotations

import numpy as np
from scipy.stats import norm

from portfolio_analytics import (BookRepricer, level_shape, twist_shape, butterfly_shape,
                                 KEY_TENORS, portfolio_summary, CCY_VOL_SCALE)

DEFAULT_CORR = np.array([[1.0, -0.3, 0.1],
                         [-0.3, 1.0, 0.2],
                         [0.1, 0.2, 1.0]])


class BondRiskMC:
    def __init__(self, book: BookRepricer, n_sims: int = 10_000, seed: int = 42):
        self.book, self.n, self.seed = book, int(n_sims), seed
        self.summary = portfolio_summary(book.df)
        self.factors_bp = None
        self.pnl = {}

    # ---------------------------------------------------------------- scenarios
    def generate_scenarios(self, vol_level_bp=100.0, vol_twist_bp=50.0, vol_fly_bp=30.0,
                           corr=DEFAULT_CORR, horizon_days=252, dist="normal", df_t=5):
        """Draw (n x 3) factor shocks in bp using Cholesky-correlated normals (or Student-t)."""
        rng = np.random.default_rng(self.seed)
        L = np.linalg.cholesky(corr)
        z = rng.standard_normal((self.n, 3))
        if dist == "t":                                   # fat tails, unit variance
            z = z / np.sqrt(rng.chisquare(df_t, (self.n, 1)) / df_t) * np.sqrt((df_t - 2) / df_t)
        vols = np.array([vol_level_bp, vol_twist_bp, vol_fly_bp]) * np.sqrt(horizon_days / 252.0)
        self.factors_bp = (z @ L.T) * vols
        self.vols_bp = vols
        return self.factors_bp

    # ---------------------------------------------------------------- P&L engines
    def _krd_setup(self):
        if not hasattr(self, "_krd"):
            k = self.book.krd_matrix()
            w_mv = self.book.base_mv
            self._krd = (w_mv[:, None] * k).sum(axis=0)       # INR DV per unit yield, per key bucket
        return self._krd

    def pnl_duration_only(self):
        """Parallel factor only: -D * dy * MV  (what the brief's first-cut engine did)."""
        dy = self.factors_bp[:, 0] / 1e4
        return -self.summary["mod_dur"] * dy * self.summary["total_mv_inr"]

    def pnl_duration_convexity(self):
        """Parallel factor with the second-order term."""
        dy = self.factors_bp[:, 0] / 1e4
        mv = self.summary["total_mv_inr"]
        return -self.summary["mod_dur"] * dy * mv + 0.5 * self.summary["convexity"] * dy ** 2 * mv

    def pnl_krd(self):
        """First-order P&L from all three factors via Key Rate Durations."""
        krd_mv = self._krd_setup()
        shape = (self.factors_bp[:, [0]] * level_shape(KEY_TENORS)
                 + self.factors_bp[:, [1]] * twist_shape(KEY_TENORS)
                 + self.factors_bp[:, [2]] * butterfly_shape(KEY_TENORS)) / 1e4   # (n x 10)
        return -(shape * krd_mv).sum(axis=1)

    def pnl_full_reval(self, n_max=None, scale_by_ccy=True):
        """Exact re-pricing of every cash flow of every bond in every scenario."""
        n = self.n if n_max is None else min(self.n, n_max)
        out = np.empty(n)
        for i in range(n):
            a, b, c = self.factors_bp[i]
            out[i] = self.book.pnl(self.book.factor_shock(a, b, c, scale_by_ccy=scale_by_ccy))
        return out

    def compute_pnl(self, full_reval=True, n_full=2_000):
        self.pnl = {"duration_only": self.pnl_duration_only(),
                    "duration_convexity": self.pnl_duration_convexity(),
                    "krd_first_order": self.pnl_krd()}
        if full_reval:
            self.pnl["full_reval"] = self.pnl_full_reval(n_full, scale_by_ccy=False)
        return self.pnl

    # ---------------------------------------------------------------- risk measures
    @staticmethod
    def var(pnl, conf=0.95):
        return float(-np.percentile(pnl, (1 - conf) * 100))

    @staticmethod
    def es(pnl, conf=0.95):
        q = np.percentile(pnl, (1 - conf) * 100)
        return float(-pnl[pnl <= q].mean())

    def parametric_var(self, conf=0.95):
        """Delta-normal VaR for the parallel factor: MV x ModDur x z x sigma_y."""
        sigma = self.vols_bp[0] / 1e4
        return self.summary["total_mv_inr"] * self.summary["mod_dur"] * norm.ppf(conf) * sigma

    def report(self, key="duration_convexity", confs=(0.95, 0.99)):
        p = self.pnl[key]
        out = {"mean": float(p.mean()), "std": float(p.std(ddof=1)),
               "max_loss": float(-p.min()), "max_gain": float(p.max())}
        for c in confs:
            out[f"VaR{int(c*100)}"] = self.var(p, c)
            out[f"ES{int(c*100)}"] = self.es(p, c)
        return out
