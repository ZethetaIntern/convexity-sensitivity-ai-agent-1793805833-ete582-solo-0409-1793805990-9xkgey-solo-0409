"""sensitivity_analysis.py - ML vs analytical price-sensitivity comparison across yield shifts."""
from __future__ import annotations
import numpy as np
import pandas as pd

from bond_pricing import (bond_price, macaulay_duration, modified_duration, convexity)
from ml_models import FEATURES_FULL, FEATURES_RAW

SHIFTS_BP = np.arange(-200, 201, 8)             # 51 points: -200 ... +200 bp in 8 bp steps


def features_at(c, years, y, cols):
    row = dict(coupon_rate=c, maturity=years, yield_rate=y,
               duration=macaulay_duration(100, c, y, years), convexity=convexity(100, c, y, years))
    return pd.DataFrame([row])[cols]


def sensitivity_table(c, years, y0, fitted, cols, shifts_bp=SHIFTS_BP):
    p0 = bond_price(100, c, y0, years)
    md, cv = modified_duration(100, c, y0, years), convexity(100, c, y0, years)
    rows = []
    for s in shifts_bp:
        dy = s / 1e4
        true = bond_price(100, c, y0 + dy, years) - p0
        row = dict(shift_bp=int(s), true_dP=true, duration_only=-md * dy * p0,
                   duration_convexity=-md * dy * p0 + 0.5 * cv * dy ** 2 * p0)
        for name, m in fitted.items():
            row[name] = float(m.predict(features_at(c, years, y0 + dy, cols))[0]) - float(
                m.predict(features_at(c, years, y0, cols))[0])
        rows.append(row)
    return pd.DataFrame(rows)


def error_summary(tab, models):
    out = []
    for col in ["duration_only", "duration_convexity", *models, "Ensemble"]:
        if col not in tab:
            continue
        e = tab[col] - tab["true_dP"]
        out.append(dict(method=col, RMSE=float(np.sqrt((e ** 2).mean())), MaxAbsErr=float(e.abs().max()),
                        Err_at_plus200=float(e.iloc[-1]), Err_at_minus200=float(e.iloc[0])))
    return pd.DataFrame(out)


def add_ensemble(tab, models, weights):
    w = np.array([weights[m] for m in models], dtype=float); w /= w.sum()
    tab["Ensemble"] = sum(wi * tab[m] for wi, m in zip(w, models))
    return tab
