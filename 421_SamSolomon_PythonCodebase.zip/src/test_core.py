"""Unit tests (stdlib unittest). Run:  python -m unittest -v test_core"""
import unittest
import numpy as np
from bond_pricing import (bond_price, macaulay_duration, modified_duration, convexity, dv01,
                          dv01_numeric, effective_duration_convexity, perpetual_metrics,
                          callable_price_bachelier)
from portfolio_analytics import build_portfolio, BookRepricer, portfolio_summary, portfolio_krd
from monte_carlo import BondRiskMC
from var_backtest import kupiec_pof, basel_zone
from yield_curve import fit_nelson_siegel, ns_curve, bootstrap_zero_curve, discount_factor


class TestBondMath(unittest.TestCase):
    def test_par_bond_prices_at_par(self):
        self.assertAlmostEqual(bond_price(100, 0.06, 0.06, 10), 100.0, places=9)

    def test_zero_coupon_duration_equals_maturity(self):
        self.assertAlmostEqual(macaulay_duration(100, 0.0, 0.05, 7), 7.0, places=9)

    def test_modified_equals_numeric_effective_duration(self):
        f = lambda y: bond_price(100, 0.0726, y, 9)
        d, c = effective_duration_convexity(f, 0.0735)
        self.assertAlmostEqual(d, modified_duration(100, 0.0726, 0.0735, 9), places=5)
        self.assertAlmostEqual(c, convexity(100, 0.0726, 0.0735, 9), places=2)

    def test_dv01_analytic_vs_numeric(self):
        self.assertAlmostEqual(dv01(100, 0.0726, 0.0735, 9), dv01_numeric(100, 0.0726, 0.0735, 9), places=6)

    def test_perpetual_closed_form(self):
        m = perpetual_metrics(0.095)
        self.assertAlmostEqual(m["mac_dur"], 11.5263, places=3)
        self.assertAlmostEqual(m["convexity"], 2 / 0.095 ** 2, places=9)

    def test_second_order_beats_first_order(self):
        p0 = bond_price(100, 0.0726, 0.0735, 9); md = modified_duration(100, 0.0726, 0.0735, 9)
        cv = convexity(100, 0.0726, 0.0735, 9); true = bond_price(100, 0.0726, 0.0835, 9) - p0
        e1 = abs(-md * 0.01 * p0 - true); e2 = abs(-md * 0.01 * p0 + 0.5 * cv * 1e-4 * p0 - true)
        self.assertLess(e2, e1 / 10)

    def test_callable_has_negative_convexity_zone(self):
        f = lambda y: callable_price_bachelier(100, 0.08, y, 10, 3)
        self.assertLess(effective_duration_convexity(f, 0.08, 0.001)[1], 0)


class TestPortfolioAndMC(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df = build_portfolio(); cls.book = BookRepricer(cls.df); cls.s = portfolio_summary(cls.df)

    def test_portfolio_size_and_value(self):
        self.assertEqual(len(self.df), 300)
        self.assertAlmostEqual(self.s["total_mv_inr"], 3.2e10, delta=1.0)
        self.assertAlmostEqual(self.df["PortfolioWeight"].sum(), 1.0, places=12)

    def test_sum_krd_matches_modified_duration_within_1pct(self):
        _, pk = portfolio_krd(self.book)
        self.assertLess(abs(pk.sum() / self.s["mod_dur"] - 1), 0.01)

    def test_mc_reproducible_and_var_ordering(self):
        a = BondRiskMC(self.book, 2000, seed=1); a.generate_scenarios(); a.compute_pnl(full_reval=False)
        b = BondRiskMC(self.book, 2000, seed=1); b.generate_scenarios(); b.compute_pnl(full_reval=False)
        np.testing.assert_allclose(a.pnl["krd_first_order"], b.pnl["krd_first_order"])
        p = a.pnl["duration_convexity"]
        self.assertGreater(a.var(p, .99), a.var(p, .95)); self.assertGreater(a.es(p, .95), a.var(p, .95))

    def test_mc_close_to_parametric_var(self):
        m = BondRiskMC(self.book, 50_000, seed=3); m.generate_scenarios(horizon_days=1); m.compute_pnl(full_reval=False)
        self.assertLess(abs(m.var(m.pnl["duration_only"]) / m.parametric_var() - 1), 0.05)


class TestRiskAndCurves(unittest.TestCase):
    def test_kupiec_and_zones(self):
        lr, p = kupiec_pof(2, 250, 0.99); self.assertGreater(p, 0.05)
        self.assertLess(kupiec_pof(10, 250, 0.99)[1], 0.01)
        self.assertEqual([basel_zone(x) for x in (4, 5, 10)], ["Green", "Yellow", "Red"])

    def test_nelson_siegel_recovers_parameters(self):
        t = np.array([0.25, .5, 1, 2, 3, 5, 7, 10, 15, 20, 30]); y = ns_curve(t, .08, -.014, -.009, 3.0)
        p, fit = fit_nelson_siegel(t, y); np.testing.assert_allclose(fit, y, atol=1e-6)

    def test_bootstrap_recovers_zero_curve(self):
        mats = np.arange(.5, 5.01, .5); z = ns_curve(mats, .08, -.014, -.009, 3.0)
        d = discount_factor(z, mats); par = 2 * (1 - d) / np.cumsum(d)
        prices = [100 * par[n] / 2 * d[:n + 1].sum() + 100 * d[n] for n in range(len(mats))]
        _, zb = bootstrap_zero_curve(mats, par, prices); np.testing.assert_allclose(zb, z, atol=1e-10)


if __name__ == "__main__":
    unittest.main()
