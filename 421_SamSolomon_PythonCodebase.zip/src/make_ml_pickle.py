import pickle, os
from ml_models import *
os.makedirs("../out", exist_ok=True)
df, stress = make_dataset(), make_stress_set(); res = {}
for feats, name in [(FEATURES_FULL, "full"), (FEATURES_RAW, "raw")]:
    fitted, tab, _ = train_and_evaluate(feats, df, stress); res[name] = (fitted, tab)
pickle.dump(res, open("../out/ml.pkl", "wb"))
