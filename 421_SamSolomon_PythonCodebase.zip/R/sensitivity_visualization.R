# sensitivity_visualization.R - adjusted duration/convexity across -2% ... +2% yield change; VaR histogram
# NOT EXECUTED in the build sandbox. Requires tidyverse, scales.
suppressPackageStartupMessages({library(tidyverse); library(scales)})
source("duration_convexity_analysis.R", echo = FALSE)       # re-uses bond_metrics()

y0 <- 0.0735; cpn <- 0.0726; yrs <- 9
shifts <- seq(-0.02, 0.02, by = 0.0025)
results <- map_dfr(shifts, function(dy) {
  m <- bond_metrics(cpn, y0 + dy, yrs)
  tibble(RateChange = dy, AdjDuration = m["mod_dur"], AdjConvexity = m["convexity"], Price = m["price"])
})
p0 <- results$Price[results$RateChange == 0]
results <- results %>% mutate(PriceChangePct = (Price / p0 - 1) * 100)
write_csv(results, "sensitivity_results.csv")

p <- ggplot(results, aes(x = RateChange)) +
  geom_line(aes(y = AdjDuration, color = "Modified duration"), linewidth = 1.2) +
  geom_line(aes(y = AdjConvexity / 10, color = "Convexity / 10"), linewidth = 1.2) +
  scale_x_continuous(labels = percent) +
  scale_y_continuous(name = "Modified duration (years)",
                     sec.axis = sec_axis(~ . * 10, name = "Convexity")) +
  labs(title = "Duration and convexity versus parallel yield change", x = "Yield change", color = "Risk measure") +
  theme_minimal(base_size = 14)
ggsave("sensitivity_chart.png", p, width = 8, height = 4.5, dpi = 200)

# VaR histogram from the Python Monte Carlo export (mc_pnl.csv has columns ScenarioID, PnL_Total_INR)
mc <- read_csv("mc_pnl.csv", show_col_types = FALSE)
var95 <- -quantile(mc$PnL_Total_INR, 0.05); es95 <- -mean(mc$PnL_Total_INR[mc$PnL_Total_INR <= -var95])
ggplot(mc, aes(PnL_Total_INR / 1e7)) + geom_histogram(bins = 70, fill = "#1F3864") +
  geom_vline(xintercept = -var95 / 1e7, color = "#E9873A", linewidth = 1) +
  geom_vline(xintercept = -es95 / 1e7, color = "black", linetype = "dashed") +
  labs(x = "P&L (INR crore)", y = "Scenarios", title = "Monte Carlo P&L with VaR95 and ES95") + theme_minimal(base_size = 14)
ggsave("var_histogram.png", width = 8, height = 4.5, dpi = 200)
