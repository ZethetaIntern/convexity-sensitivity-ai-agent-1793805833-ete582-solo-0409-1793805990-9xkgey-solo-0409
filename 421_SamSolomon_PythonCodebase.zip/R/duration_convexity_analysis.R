# duration_convexity_analysis.R - GBM, XGBoost and H2O neural network for duration / convexity
# NOT EXECUTED in the build sandbox (R unavailable). Requires: tidyverse, caret, gbm, xgboost, h2o (Java 8+), Metrics
suppressPackageStartupMessages({library(tidyverse); library(caret); library(xgboost); library(h2o); library(Metrics)})
set.seed(42)

bond_metrics <- function(cpn, ytm, yrs, f = 2) {
  n  <- ceiling(yrs * f - 1e-9)
  t  <- yrs + (seq_len(n) - n) / f                    # ascending cash-flow times ending at maturity
  cf <- rep(100 * cpn / f, n); cf[n] <- cf[n] + 100
  k  <- f * t; pv <- cf / (1 + ytm / f)^k
  mac <- sum(t * pv) / sum(pv)
  c(price = sum(pv), mac_dur = mac, mod_dur = mac / (1 + ytm / f),
    convexity = sum(k * (k + 1) * pv) / (sum(pv) * f^2 * (1 + ytm / f)^2))
}

n <- 5000
bonds <- tibble(CouponRate = round(runif(n, .04, .10), 4),
                YearsToMaturity = sample(seq(1, 30, .5), n, TRUE),
                YieldToMaturity = runif(n, .045, .095))
metrics <- t(mapply(bond_metrics, bonds$CouponRate, bonds$YieldToMaturity, bonds$YearsToMaturity))
data <- bind_cols(bonds, as_tibble(metrics))
feat <- c("CouponRate", "YearsToMaturity", "YieldToMaturity")

idx   <- createDataPartition(data$mod_dur, p = .8, list = FALSE)
train <- data[idx, ]; test <- data[-idx, ]

# 1. Gradient boosting machine (caret) for modified duration, 5-fold CV
gbm_dur <- train(x = as.data.frame(train[feat]), y = train$mod_dur, method = "gbm", verbose = FALSE,
                 trControl = trainControl(method = "cv", number = 5))
rmse_gbm <- rmse(test$mod_dur, predict(gbm_dur, as.data.frame(test[feat])))

# 2. XGBoost for convexity
xgb_conv <- xgboost(data = as.matrix(train[feat]), label = train$convexity,
                    max_depth = 4, eta = 0.1, nrounds = 100, verbose = 0)
rmse_xgb <- rmse(test$convexity, predict(xgb_conv, as.matrix(test[feat])))

# 3. H2O deep network for modified duration
h2o.init(nthreads = -1)
h  <- as.h2o(as.data.frame(data)); sp <- h2o.splitFrame(h, ratios = .8, seed = 42)
nn <- h2o.deeplearning(x = feat, y = "mod_dur", training_frame = sp[[1]], validation_frame = sp[[2]],
                       activation = "RectifierWithDropout", hidden = c(100, 50),
                       hidden_dropout_ratios = c(.1, .1), epochs = 50, seed = 42)
rmse_nn <- h2o.rmse(h2o.performance(nn, newdata = sp[[2]]))

results <- tibble(Model = c("GBM (mod duration)", "XGBoost (convexity)", "H2O NN (mod duration)"),
                  RMSE = c(rmse_gbm, rmse_xgb, rmse_nn))
print(results)
write_csv(results, "ml_results_R.csv")
